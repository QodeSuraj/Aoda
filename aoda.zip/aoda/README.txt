=== Access Pro ===
Tags: Accessibility, A11y, Toolbar, Tools, wcag, Section 508
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The Access Pro WordPress plugin is a valuable tool for website owners looking to adhere to the Accessibility for Ontarians with Disabilities Act. By improving accessibility, this plugin helps ensure a more inclusive online experience, catering to users with disabilities, and aligning with legal compliance requirements for web accessibility in Ontario, Canada.

== Description ==

The Access Pro WordPress plugin is the fastest plugin to help you make your WordPress website more accessible.

While most accessibility issues can’t be addressed without directly changing your content, Access Pro adds a number of helpful accessibility features with the minimum amount of setup and without the need for expert knowledge.

== Installation ==

**Automatic Installation**

1. Install using the WordPress built-in Plugin installer > Add New
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to the plugin page (under Dashboard > Access Pro)
1. Enjoy!

**Manual Installation**

1. Extract the zip file and just drop the contents in the <code>wp-content/plugins/</code> directory of your WordPress installation
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to the plugin page (under Dashboard > Access Pro)
1. Enjoy!

== Screenshots ==

1. The main plugin interface.

== Changelog ==

= 1.0.0 - 2023-10-30 =
* Initial Public Release!
