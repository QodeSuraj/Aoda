<?php

namespace Access_Pro\Api\Admin;

use WP_REST_Controller;

class Settings_Route extends WP_REST_Controller
{

    const BASE_URL = "https://app.accesspro.ai/api/";
    // const BASE_URL = "http://localhost:8070/api/";
    protected $namespace;
    protected $rest_base;
    protected $table_prefix;

    public function __construct()
    {
        global $wpdb;
        $this->namespace = 'ap/v1';
        $this->rest_base = 'settings';
        $this->table_prefix = $wpdb->prefix . "access_pro_";
    }

    /**
     * Register Routes
     */
    public function register_routes()
    {

        register_rest_route(
            $this->namespace,
            '/settings/save-config-data',
            [
                [
                    'methods'             => 'POST',
                    'callback'            => [$this, 'save_config_data'],
                    'permission_callback' => [$this, 'create_items_permission_check'],
                ]
            ]
        );
        
        register_rest_route(
            $this->namespace,
            '/public/translate',
            [
                [
                    'methods'             => 'POST',
                    'callback'            => [$this, 'translate'],
                    'permission_callback' => [$this, 'create_items_permission_check'],
                ]
            ]
        );
        
        register_rest_route(
            $this->namespace,
            '/public/get-plugin-content',
            [
                [
                    'methods'             => 'POST',
                    'callback'            => [$this, 'getPluginContent'],
                ]
            ]
        );
    }

    public function save_config_data($request)
    {
        global $wpdb;

        // Get JSON data from the request body
        $json_data = $request->get_json_params();

        if (is_array($json_data)) {
            foreach ($json_data as $key => $value) {
                $wpdb->update(
                    $this->table_prefix . "configs",
                    array('value' => $value),
                    array('key' => $key)
                );
            }

            return rest_ensure_response(['status' => 'success', 'message' => 'Settings updated successfully']);
        } else {
            return rest_ensure_response(['status' => 'error', 'message' => 'Invalid JSON payload']);
        }
    }

    public function translate($request)
    {
        $translations = [
            "MENU TITLE" => "Accessibility Settings",
            "OUR MISSION" => "Our Mission",
            "RESET TITLE" => "Reset Settings",
            "PROFILE TITLE" => "Accessibility profiles",
            "READER PROFILE TITLE" => "Reader Profile",
            "READER PROFILE HEAD" => "Creates a focused reading experience",
            "READER PROFILE DESC" => "This profile hide images & videos and stop animations, to focus on the text content of the website more easily.",
            "SEIZURE PROFILE TITLE" => "Seizure Safe Profile",
            "SEIZURE PROFILE HEAD" => "Clear Flashes & reduces color",
            "SEIZURE PROFILE DESC" => "This profile enables epileptic and seizure prone users to browse safely by eliminating the risk of seizures that result from flashing or blinking animations and risky color combinations.",
            "ADHD PROFILE TITLE" => "ADHD Friendly Profile",
            "ADHD PROFILE HEAD" => "More focus & fewer distractions",
            "ADHD PROFILE DESC" => "This profile significantly reduces distractions, to help people with ADHD and Neurodevelopmental disorders browse, read, and focus on the essential elements of the website more easily.",
            "COGNITIVE PROFILE TITLE" => "Cognitive Disability Profile",
            "COGNITIVE PROFILE HEAD" => "Assists with reading & focusing",
            "COGNITIVE PROFILE DESC" => "This profile provides various assistive features to help users with cognitive disabilities such as Autism, Dyslexia, CVA, and others, to focus on the essential elements of the website more easily.",
            "OFF" => "OFF",
            "ON" => "ON",
            "CONTENT SETTINGS" => "Content Settings",
            "FONT SCALE" => "Font Scale",
            "LINE SPACING" => "Increase Line Spacing",
            "LETTER SPACING" => "Increase Letter Spacing",
            "DYSLEXIC FONT" => "Use Dyslexic Font",
            "FONT WEIGHT" => "Increase Font Weight",
            "TEXT ALIGN" => "Text<br>Alignment",
            "LEFT" => "Left",
            "CENTER" => "Center",
            "RIGHT" => "Right",
            "CONTRAST" => "Contrast<br>Mode",
            "DARK" => "Dark",
            "LIGHT" => "Light",
            "HIGH" => "High",
            "SATURATION" => "Color<br>Saturation",
            "LOW" => "Low",
            "BLACK & WHITE" => "Black & White",
            "BROWSING SETTINGS" => "Browsing Settings",
            "CURSOR" => "Cursor Size",
            "TEXT MAGNIFIER" => "Text Magnifier",
            "READING GUIDE" => "Reading Guide",
            "READING MASK" => "Reading Mask",
            "HIGHLIGHT HEADINGS" => "Highlight Headings",
            "HIGHLIGHT LINKS" => "Highlight Links",
            "STOP ANIMATION" => "Stop Animation",
            "MUTE SOUNDS" => "Mute Sounds",
            "HIDE IMAGES" => "Hide Images",
            "DESCRIBE IMAGES" => "Describe Images",
            "TEXT TO SPEECH" => "Text to Speech",
            "HIDE VIDEO" => "Hide Video"
        ];
        $data = $request->get_json_params();
        $languageCode = $data["translateTo"];
        $translationsFilePath = dirname(__DIR__, 1) . '/locale/' . $languageCode . '.json';

        if ($languageCode !== "en" && file_exists($translationsFilePath)) {
            $fileContents = file_get_contents($translationsFilePath);
            $fileTranslations = json_decode($fileContents, true);

            if (!is_null($fileTranslations)) {
                foreach ($translations as $key => $value) {
                    if (array_key_exists($key, $fileTranslations)) {
                        $translations[$key] = $fileTranslations[$key];
                    }
                }
            }
        }

        return rest_ensure_response(['status' => 'success', 'data' => $translations]);
    }

    public function get_api_key()
    {
        global $wpdb;
        $prefix = $this->table_prefix;

        $sql = "SELECT `key`,`value` FROM `{$prefix}configs` where `key`='api_key'";
        $all_configs_result = $wpdb->get_results($sql);

        $all_configs = array();
        foreach ($all_configs_result as $config) {
            $all_configs[$config->key] = $config->value;
        }

        return $all_configs['api_key'];
    }

    public function getPluginContent($request)
    {
        $url = self::BASE_URL . 'access-pro';
        $apikey = $this->get_api_key();
        $response = wp_remote_post($url, array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'ap-api-key' => $apikey,
                'ap-plugin-host' => $request->get_params()['hostname'],
            ),
        ));

        if (is_wp_error($response)) {
            return rest_ensure_response(wp_remote_retrieve_body($response), $response->get_error_code());
        } else {
            return rest_ensure_response(wp_remote_retrieve_body($response), 200);
        }
    }


    /**
     * Create item permission check
     */
    public function create_items_permission_check($request)
    {
        return true;
    }

}
