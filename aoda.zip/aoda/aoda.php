<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://qodemedia.com
 * @since             1.0.0
 * @package           Access_Pro
 *
 * @wordpress-plugin
 * Plugin Name:       Access Pro
 * Plugin URI:        https://qodemedia.com
 * Description:       The Access Pro WordPress plugin is a valuable tool for website owners looking to adhere to the Accessibility for Ontarians with Disabilities Act. By improving accessibility, this plugin helps ensure a more inclusive online experience, catering to users with disabilities, and aligning with legal compliance requirements for web accessibility in Ontario, Canada.
 * Version:           1.0.1
 * Author:            Qodemedia
 * Author URI:        https://qodemedia.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       access-pro
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Require Autoloader
 */
require_once 'vendor/autoload.php';

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'ACCESS_PRO_VERSION', '1.0.0' );
define('AP_PLUGIN_URL', trailingslashit(plugins_url('', __FILE__)));

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-access-pro-activator.php
 */
function activate_access_pro() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-access-pro-activator.php';
	Access_Pro_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-access-pro-deactivator.php
 */
function deactivate_access_pro() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-access-pro-deactivator.php';
	Access_Pro_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_access_pro' );
register_deactivation_hook( __FILE__, 'deactivate_access_pro' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-access-pro.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_access_pro() {

	$plugin = new Access_Pro();
	$plugin->run();

}
run_access_pro();
