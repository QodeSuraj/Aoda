<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://qodemedia.com
 * @since      1.0.0
 *
 * @package    Access_Pro
 * @subpackage Access_Pro/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Access_Pro
 * @subpackage Access_Pro/public
 * @author     qodemedia <avi@qodemedia.com>
 */
class Access_Pro_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Access_Pro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Access_Pro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		// wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/access-pro-public.css', array(), $this->version, 'all' );
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/style.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Access_Pro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Access_Pro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( 'access-pro-public', plugin_dir_url( __FILE__ ) . 'js/access-pro-public.js', array( 'jquery' ), $this->version, false );
		// wp_enqueue_script('access-pro-public', plugin_dir_url( __FILE__ ) . 'js/app.js', array( 'jquery' ), $this->version, false );
		// wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/app.js', [], $this->version, true );
		$all_configs = $this->get_all_configs_data();
		wp_localize_script('access-pro-public', 'apPublicLocalizer', [
			'publicImageURL' => AP_PLUGIN_URL . 'public/images',
			'restUrl' => home_url('/wp-json'),
			'configs' => $all_configs,
		]);
	}

	/**
	 * [display_plugin_setup_page description]
	 * @return [type] [description]
	 */
	public function display_public_page()
	{
		global $wpdb;
		$prefix = $wpdb->prefix . "access_pro_";

		// Check if 'enable_features' is set to 1
		$enable_features = $wpdb->get_var("SELECT `value` FROM `{$prefix}configs` WHERE `key` = 'enable_features'");

		if ($enable_features === '1') {
			include_once('partials/access-pro-public-display.php');
		}
	}

	/**
	 * Get All Configs Data
	 *
	 * @return array
	 */
	function get_all_configs_data()
	{
		global $wpdb;
		$prefix 	 	 = $wpdb->prefix . "access_pro_";

		$sql = "SELECT `key`,`value` FROM `{$prefix}configs`";
		$all_configs_result = $wpdb->get_results($sql);

		$all_configs = array();
		foreach ($all_configs_result as $config) {
			$all_configs[$config->key] = $config->value;
		}
		return $all_configs;
	}

}
