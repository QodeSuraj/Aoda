<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://qodemedia.com
 * @since      1.0.0
 *
 * @package    Access_Pro
 * @subpackage Access_Pro/public/partials
 */
?>
<div class="asw-widget">
    <svg style="display: none;" class="asw-menu-btn" id="asw-icon" title="Open Accessibility Menu" role="button" aria-expanded="false" onclick="toggleMenu()" width=" 80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g filter="url(#filter0_d_814_50)">
            <rect x="10" y="6" width="60" height="60" rx="30" fill="white" />
            <rect id="apMenuIconStroke" x="12.5" y="8.5" width="55" height="55" rx="27.5" stroke="#419D4A" stroke-width="5" />
            <path id="apMenuIconFill" d="M40 16C51.0156 16 60 24.9844 60 36C60 47.0938 51.0156 56 40 56C28.9062 56 20 47.0938 20 36C20 24.9844 28.9062 16 40 16ZM40 22.25C38.2031 22.25 36.875 23.6562 36.875 25.375C36.875 27.1719 38.2031 28.5 40 28.5C41.7188 28.5 43.125 27.1719 43.125 25.375C43.125 23.6562 41.7188 22.25 40 22.25ZM49.2188 32.875C50.2344 32.5625 50.7812 31.5469 50.5469 30.5312C50.2344 29.5156 49.2188 28.9688 48.2031 29.2031L43.5938 30.5312C41.25 31.2344 38.75 31.2344 36.3281 30.5312L31.7188 29.2031C30.7031 28.9688 29.6875 29.5156 29.375 30.5312C29.1406 31.5469 29.6875 32.5625 30.7031 32.875L35.3125 34.125C35.625 34.2812 35.9375 34.2812 36.25 34.3594V39.2031L33.8281 46.0781C33.4375 47.0156 33.9844 48.1094 35 48.4219C35.1562 48.5 35.3906 48.5 35.625 48.5C36.3281 48.5 37.1094 48.0312 37.3438 47.25L39.375 41.7812C39.6094 41.2344 40.3125 41.2344 40.5469 41.7812L42.5781 47.25C42.8125 48.0312 43.5938 48.5 44.375 48.5C44.5312 48.5 44.7656 48.5 44.9219 48.4219C45.9375 48.1094 46.4844 47.0156 46.0938 46.0781L43.75 39.2031V34.3594C43.9844 34.2812 44.2969 34.2812 44.6094 34.125L49.2188 32.875Z" fill="#419D4A" />
        </g>
        <defs>
            <filter id="filter0_d_814_50" x="0" y="0" width="80" height="80" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                <feOffset dy="4" />
                <feGaussianBlur stdDeviation="5" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0" />
                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_814_50" />
                <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_814_50" result="shape" />
            </filter>
        </defs>
    </svg>
</div>

<div class="asw-menu" style="display: none;" id="aswMenu">
    <div class="ap-compliance-statement-wrapper" id="ap-compliance-statement" style="display: none;">
        <div class="ap-compliance-statement">
            <div class="ap-compliance-statement-heading-wrapper">
                <span role="button" class="asw-menu-close" onclick="toggleComplianceStatement()" style="font-size: 32px;">&times;</span>
                <span class="ap-compliance-statement-heading">AccessPro Compliance Mission Statement</span>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">WCAG 2.2 Commitment:</span> We strictly adhere to WCAG 2.2 AA guidelines.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Personalized UI:</span> Users with disabilities can personalize the interface.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">AI-Based Compliance:</span> We use AI to maintain accessibility during updates.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">ARIA Attributes:</span> Meaningful data for screen-readers using ARIA attributes.</p>
            </div>

            <p class="ap-bold-text" style="text-align: center; margin-top: 22px;">Optimized Screen Reader and Keyboard Navigation:</p>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Screen-reader Optimization:</span> ARIA attributes for meaningful data.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Image Description:</span> Auto image descriptions for better understanding.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">OCR Technology:</span> Text extraction from images.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Keyboard Navigation:</span> Enhanced keyboard operability.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Content-skip Menus:</span> Easy navigation with shortcuts.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Popup Handling:</span> Improved handling of popups.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Shortcuts:</span> Quick access to key elements with shortcuts.</p>
            </div>

            <p class="ap-bold-text" style="text-align: center; margin-top: 22px;">Specialized Profiles for Disabilities:</p>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Epilepsy Safe Profile:</span> Safe browsing with reduced triggers.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Vision Impaired Profile:</span> Enhanced interface for visual impairments.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Cognitive Disability Profile:</span> Assistive features for cognitive disabilities.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">ADHD-Friendly Profile:</span> Minimized distractions for ADHD users.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Blind Users Profile:</span> Compatibility with popular screen-readers.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Keyboard Navigation Profile:</span> Navigate with keyboard commands.</p>
            </div>

            <p class="ap-bold-text" style="text-align: center; margin-top: 22px;">Customizable User Interface Adjustments:</p>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Font Adjustments:</span> Customize font settings for readability.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Colour Adjustments:</span> Choose contrast profiles and color schemes.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Animations</span> Disable animations for user safety.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Content Highlighting:</span> Emphasize key elements.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Audio Muting:</span> Instantly mute the website.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Cognitive Disorders:</span> Linked search engine for better understanding.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Additional Functions:</span> Various customizable options.</p>
            </div>

            <p class="ap-bold-text" style="text-align: center; margin-top: 22px;">Browser and Assistive Technology Support:</p>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Supported Browsers:</span> Google Chrome, Mozilla Firefox, Apple Safari, Opera, Microsoft Edge.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Supported Screen Readers:</span> JAWS (Windows/MAC), NVDA (Windows/MAC).</p>
            </div>

            <p class="ap-bold-text" style="text-align: center; margin-top: 22px;">Continual Accessibility Improvement:</p>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Ongoing Efforts:</span> We continuously enhance accessibility.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Goal:</span> Achieve maximum accessibility with evolving technology.</p>
            </div>
            <div class="ap-compliance-statement-points">
                <div style="padding-top: 5px;">
                    <div class="ap-compliance-statement-bullet"></div>
                </div>
                <p><span class="ap-bold-text">Contact Us:</span> Reach out via the website’s contact form for queries or concerns.</p>
            </div>
        </div>
    </div>
    <div class="asw-menu-header ap-black-bg" id="draggableHeader">
        <div data-ap-translate="MENU TITLE">
            Accessibility Settings
        </div>
        <span role="button" class="asw-menu-close" title="Close Accessibility Settings" onclick="toggleMenu()">&times;</span>
    </div>
    <div class="asw-reset ap-gray-bg">
        <div id="asw-website-lang" class="ap-fw-400 ap-font-18"></div>
        <div role="button" class="asw-menu-reset" onclick="toggleComplianceStatement()">
            <span class="ap-fw-400 ap-font-18" data-ap-translate="OUR MISSION">Our Mission</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 448 512" fill="none" style="margin-left: 9px; width: 14px;">
                <path d="M0 96C0 43 43 0 96 0h96V190.7c0 13.4 15.5 20.9 26 12.5L272 160l54 43.2c10.5 8.4 26 .9 26-12.5V0h32 32c17.7 0 32 14.3 32 32V352c0 17.7-14.3 32-32 32v64c17.7 0 32 14.3 32 32s-14.3 32-32 32H384 96c-53 0-96-43-96-96V96zM64 416c0 17.7 14.3 32 32 32H352V384H96c-17.7 0-32 14.3-32 32z" />
            </svg>
        </div>
        <div role="button" class="asw-menu-reset" title="Reset settings" onclick="reset()">
            <span class="ap-fw-400 ap-font-18" data-ap-translate="RESET TITLE">Reset Settings</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none" style="margin-left: 9px;">
                <mask id="mask0_884_396" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="25">
                    <rect y="0.5" width="24" height="24" fill="#D9D9D9" />
                </mask>
                <g mask="url(#mask0_884_396)">
                    <path d="M9.825 21.2C8.10833 20.7167 6.70833 19.7708 5.625 18.3625C4.54167 16.9542 4 15.3333 4 13.5C4 12.55 4.15833 11.6458 4.475 10.7875C4.79167 9.92916 5.24167 9.14165 5.825 8.42499C6.00833 8.22499 6.23333 8.12082 6.5 8.11249C6.76667 8.10416 7.00833 8.20832 7.225 8.42499C7.40833 8.60832 7.50417 8.83332 7.5125 9.09999C7.52083 9.36666 7.43333 9.61666 7.25 9.84999C6.85 10.3667 6.54167 10.9333 6.325 11.55C6.10833 12.1667 6 12.8167 6 13.5C6 14.85 6.39583 16.0542 7.1875 17.1125C7.97917 18.1708 9 18.8917 10.25 19.275C10.4667 19.3417 10.6458 19.4667 10.7875 19.65C10.9292 19.8333 11 20.0333 11 20.25C11 20.5833 10.8833 20.8458 10.65 21.0375C10.4167 21.2292 10.1417 21.2833 9.825 21.2ZM14.175 21.2C13.8583 21.2833 13.5833 21.225 13.35 21.025C13.1167 20.825 13 20.5583 13 20.225C13 20.025 13.0708 19.8333 13.2125 19.65C13.3542 19.4667 13.5333 19.3417 13.75 19.275C15 18.875 16.0208 18.15 16.8125 17.1C17.6042 16.05 18 14.85 18 13.5C18 11.8333 17.4167 10.4167 16.25 9.24999C15.0833 8.08332 13.6667 7.49999 12 7.49999H11.925L12.325 7.89999C12.5083 8.08332 12.6 8.31666 12.6 8.59999C12.6 8.88332 12.5083 9.11665 12.325 9.29999C12.1417 9.48332 11.9083 9.57499 11.625 9.57499C11.3417 9.57499 11.1083 9.48332 10.925 9.29999L8.825 7.19999C8.725 7.09999 8.65417 6.99165 8.6125 6.87499C8.57083 6.75832 8.55 6.63332 8.55 6.49999C8.55 6.36665 8.57083 6.24165 8.6125 6.12499C8.65417 6.00832 8.725 5.89999 8.825 5.79999L10.925 3.69999C11.1083 3.51665 11.3417 3.42499 11.625 3.42499C11.9083 3.42499 12.1417 3.51665 12.325 3.69999C12.5083 3.88332 12.6 4.11665 12.6 4.39999C12.6 4.68332 12.5083 4.91665 12.325 5.09999L11.925 5.49999H12C14.2333 5.49999 16.125 6.27499 17.675 7.82499C19.225 9.37499 20 11.2667 20 13.5C20 15.3167 19.4583 16.9333 18.375 18.35C17.2917 19.7667 15.8917 20.7167 14.175 21.2Z" fill="black" />
                </g>
            </svg>
        </div>
    </div>
    <div class="asw-menu-content">
        <div class="asw-card asw-actions ap-border-bottom">
            <div class="ap-fw-400 ap-font-18 ap-cursor-pointer" onclick="toggleLanguageAccordion()">
                <div class="ap-profile-heading">
                    <span id="ap-selected-language">English (USA)</span>
                    <svg id="ap-language-heading-chev" width="17" height="10" viewBox="0 0 17 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8.875 0.125C9.19141 0.125 9.47266 0.230469 9.68359 0.441406L16.4336 7.19141C16.8906 7.61328 16.8906 8.35156 16.4336 8.77344C16.0117 9.23047 15.2734 9.23047 14.8516 8.77344L8.875 2.83203L2.93359 8.77344C2.51172 9.23047 1.77344 9.23047 1.35156 8.77344C0.894531 8.35156 0.894531 7.61328 1.35156 7.19141L8.10156 0.441406C8.3125 0.230469 8.59375 0.125 8.875 0.125Z" fill="black" />
                    </svg>
                </div>
                <br />
            </div>
            <div id="asw-language-wrapper"></div>
        </div>
        <div class="asw-card asw-actions ap-border-bottom">
            <div class="ap-fw-400 ap-font-18 ap-cursor-pointer" id="apToggleActionBtn" tabindex="0" onclick="toggleActions()">
                <div class="ap-profile-heading">
                    <span data-ap-translate="PROFILE TITLE">Accessibility profiles</span>
                    <svg id="ap-profile-heading-chev" width="17" height="10" viewBox="0 0 17 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8.875 0.125C9.19141 0.125 9.47266 0.230469 9.68359 0.441406L16.4336 7.19141C16.8906 7.61328 16.8906 8.35156 16.4336 8.77344C16.0117 9.23047 15.2734 9.23047 14.8516 8.77344L8.875 2.83203L2.93359 8.77344C2.51172 9.23047 1.77344 9.23047 1.35156 8.77344C0.894531 8.35156 0.894531 7.61328 1.35156 7.19141L8.10156 0.441406C8.3125 0.230469 8.59375 0.125 8.875 0.125Z" fill="black" />
                    </svg>
                </div>
                <br />
            </div>
            <div id="asw-actions-wrapper">
                <div class="asw-action">
                    <div class="asw-action-heading">
                        <div class="asw-action-heading-left">
                            <div class="asw-action-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                    <path d="M24,7V5H4v18c0,2.209,1.791,4,4,4h16c2.209,0,4-1.791,4-4V7H24z M26,23c0,1.105-0.895,2-2,2H8	c-1.105,0-2-0.895-2-2V7h16v16h2V9h2V23z M14,9H8v6h6V9z M12,13h-2v-2h2V13z M16,9h4v2h-4V9z M16,13h4v2h-4V13z M8,17h12v2H8V17z M8,21h12v2H8V21z" fill="black" />
                                </svg>
                            </div>
                            <div class="asw-action-desc">
                                <span class="asw-action-desc-title" data-ap-translate="READER PROFILE TITLE">Reader Profile</span>
                                <span class="asw-action-desc-desc" data-ap-translate="READER PROFILE HEAD">Creates a focused reading experience</span>
                            </div>
                        </div>
                        <div class="asw-action-heading-right">
                            <label class="asw-switch">
                                <input class="asw-action-switch-toggle" type="checkbox" onchange="toggleReadMode(event)">
                                <span class="asw-switch-off">
                                    <span data-ap-translate="OFF">OFF</span>
                                </span>
                                <span class="asw-switch-on">
                                    <span data-ap-translate="ON">ON</span>
                                </span>
                            </label>
                        </div>
                    </div>
                    <div class="asw-action-description" data-ap-translate="READER PROFILE DESC">
                        This profile hide images & videos and stop animations, to focus on the text content of the website more easily.
                    </div>
                </div>
                <div class="asw-action">
                    <div class="asw-action-heading">
                        <div class="asw-action-heading-left">
                            <div class="asw-action-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none">
                                    <mask id="mask0_949_139" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="36" height="36">
                                        <rect x="0.5" y="0.5" width="35" height="35" fill="#D9D9D9" />
                                    </mask>
                                    <g mask="url(#mask0_949_139)">
                                        <path d="M15.8855 27.0417L23.4323 18H17.599L18.6563 9.72396L11.9115 19.4583H16.9792L15.8855 27.0417ZM13.625 22.375H9.1042C8.52087 22.375 8.08945 22.1137 7.80993 21.5912C7.53042 21.0686 7.5608 20.5642 7.90108 20.0781L18.8021 4.40105C19.0452 4.06077 19.3611 3.82379 19.75 3.69011C20.1389 3.55643 20.54 3.5625 20.9532 3.70834C21.3664 3.85417 21.6702 4.10938 21.8646 4.47396C22.0591 4.83855 22.132 5.22744 22.0834 5.64063L20.9167 15.0833H26.5677C27.1997 15.0833 27.6433 15.3629 27.8985 15.9219C28.1537 16.4809 28.0747 17.0035 27.6615 17.4896L15.6667 31.8542C15.3993 32.1701 15.0712 32.3767 14.6823 32.474C14.2934 32.5712 13.9167 32.5347 13.5521 32.3646C13.1875 32.1944 12.9019 31.9332 12.6953 31.5807C12.4888 31.2283 12.4098 30.8455 12.4584 30.4323L13.625 22.375Z" fill="black" />
                                    </g>
                                </svg>
                            </div>
                            <div class="asw-action-desc">
                                <span class="asw-action-desc-title" data-ap-translate="SEIZURE PROFILE TITLE">Seizure Safe Profile</span>
                                <span class="asw-action-desc-desc" data-ap-translate="SEIZURE PROFILE HEAD">Clear Flashes & reduces color</span>
                            </div>
                        </div>
                        <div class="asw-action-heading-right">
                            <label class="asw-switch">
                                <input type="checkbox" onchange="toggleSeizure(event)">
                                <span class="asw-switch-off">
                                    <span data-ap-translate="OFF">OFF</span>
                                </span>
                                <span class="asw-switch-on">
                                    <span data-ap-translate="ON">ON</span>
                                </span>
                            </label>
                        </div>
                    </div>
                    <div class="asw-action-description" data-ap-translate="SEIZURE PROFILE DESC">
                        This profile enables epileptic and seizure prone users to browse safely by eliminating the risk of seizures that result from flashing or blinking animations and risky color combinations.
                    </div>
                </div>
                <div class="asw-action">
                    <div class="asw-action-heading">
                        <div class="asw-action-heading-left">
                            <div class="asw-action-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none">
                                    <mask id="mask0_949_169" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="36" height="36">
                                        <rect x="0.5" y="0.5" width="35" height="35" fill="#D9D9D9" />
                                    </mask>
                                    <g mask="url(#mask0_949_169)">
                                        <path d="M6.33333 31.125C5.92014 31.125 5.57378 30.9852 5.29427 30.7057C5.01476 30.4262 4.875 30.0799 4.875 29.6667C4.875 29.2535 5.01476 28.9071 5.29427 28.6276C5.57378 28.3481 5.92014 28.2083 6.33333 28.2083H7.79167C8.20486 28.2083 8.55122 28.3481 8.83073 28.6276C9.11024 28.9071 9.25 29.2535 9.25 29.6667C9.25 30.0799 9.11024 30.4262 8.83073 30.7057C8.55122 30.9852 8.20486 31.125 7.79167 31.125H6.33333ZM6.33333 25.2917C5.92014 25.2917 5.57378 25.1519 5.29427 24.8724C5.01476 24.5929 4.875 24.2465 4.875 23.8333C4.875 23.4201 5.01476 23.0738 5.29427 22.7943C5.57378 22.5148 5.92014 22.375 6.33333 22.375H15.0833C15.4965 22.375 15.8429 22.5148 16.1224 22.7943C16.4019 23.0738 16.5417 23.4201 16.5417 23.8333C16.5417 24.2465 16.4019 24.5929 16.1224 24.8724C15.8429 25.1519 15.4965 25.2917 15.0833 25.2917H6.33333ZM6.33333 19.4583C5.92014 19.4583 5.57378 19.3186 5.29427 19.0391C5.01476 18.7596 4.875 18.4132 4.875 18C4.875 17.5868 5.01476 17.2405 5.29427 16.9609C5.57378 16.6814 5.92014 16.5417 6.33333 16.5417H29.6667C30.0799 16.5417 30.4262 16.6814 30.7057 16.9609C30.9852 17.2405 31.125 17.5868 31.125 18C31.125 18.4132 30.9852 18.7596 30.7057 19.0391C30.4262 19.3186 30.0799 19.4583 29.6667 19.4583H6.33333ZM6.33333 13.625C5.92014 13.625 5.57378 13.4852 5.29427 13.2057C5.01476 12.9262 4.875 12.5799 4.875 12.1667C4.875 11.7535 5.01476 11.4071 5.29427 11.1276C5.57378 10.8481 5.92014 10.7083 6.33333 10.7083H15.0833C15.4965 10.7083 15.8429 10.8481 16.1224 11.1276C16.4019 11.4071 16.5417 11.7535 16.5417 12.1667C16.5417 12.5799 16.4019 12.9262 16.1224 13.2057C15.8429 13.4852 15.4965 13.625 15.0833 13.625H6.33333ZM6.33333 7.79167C5.92014 7.79167 5.57378 7.65191 5.29427 7.3724C5.01476 7.09288 4.875 6.74653 4.875 6.33333C4.875 5.92014 5.01476 5.57378 5.29427 5.29427C5.57378 5.01476 5.92014 4.875 6.33333 4.875H7.79167C8.20486 4.875 8.55122 5.01476 8.83073 5.29427C9.11024 5.57378 9.25 5.92014 9.25 6.33333C9.25 6.74653 9.11024 7.09288 8.83073 7.3724C8.55122 7.65191 8.20486 7.79167 7.79167 7.79167H6.33333ZM13.625 31.125C13.2118 31.125 12.8655 30.9852 12.5859 30.7057C12.3064 30.4262 12.1667 30.0799 12.1667 29.6667C12.1667 29.2535 12.3064 28.9071 12.5859 28.6276C12.8655 28.3481 13.2118 28.2083 13.625 28.2083H15.0833C15.4965 28.2083 15.8429 28.3481 16.1224 28.6276C16.4019 28.9071 16.5417 29.2535 16.5417 29.6667C16.5417 30.0799 16.4019 30.4262 16.1224 30.7057C15.8429 30.9852 15.4965 31.125 15.0833 31.125H13.625ZM13.625 7.79167C13.2118 7.79167 12.8655 7.65191 12.5859 7.3724C12.3064 7.09288 12.1667 6.74653 12.1667 6.33333C12.1667 5.92014 12.3064 5.57378 12.5859 5.29427C12.8655 5.01476 13.2118 4.875 13.625 4.875H15.0833C15.4965 4.875 15.8429 5.01476 16.1224 5.29427C16.4019 5.57378 16.5417 5.92014 16.5417 6.33333C16.5417 6.74653 16.4019 7.09288 16.1224 7.3724C15.8429 7.65191 15.4965 7.79167 15.0833 7.79167H13.625ZM20.9167 31.125C20.5035 31.125 20.1571 30.9852 19.8776 30.7057C19.5981 30.4262 19.4583 30.0799 19.4583 29.6667C19.4583 29.2535 19.5981 28.9071 19.8776 28.6276C20.1571 28.3481 20.5035 28.2083 20.9167 28.2083H22.375C22.7882 28.2083 23.1346 28.3481 23.4141 28.6276C23.6936 28.9071 23.8333 29.2535 23.8333 29.6667C23.8333 30.0799 23.6936 30.4262 23.4141 30.7057C23.1346 30.9852 22.7882 31.125 22.375 31.125H20.9167ZM20.9167 25.2917C20.5035 25.2917 20.1571 25.1519 19.8776 24.8724C19.5981 24.5929 19.4583 24.2465 19.4583 23.8333C19.4583 23.4201 19.5981 23.0738 19.8776 22.7943C20.1571 22.5148 20.5035 22.375 20.9167 22.375H29.6667C30.0799 22.375 30.4262 22.5148 30.7057 22.7943C30.9852 23.0738 31.125 23.4201 31.125 23.8333C31.125 24.2465 30.9852 24.5929 30.7057 24.8724C30.4262 25.1519 30.0799 25.2917 29.6667 25.2917H20.9167ZM20.9167 13.625C20.5035 13.625 20.1571 13.4852 19.8776 13.2057C19.5981 12.9262 19.4583 12.5799 19.4583 12.1667C19.4583 11.7535 19.5981 11.4071 19.8776 11.1276C20.1571 10.8481 20.5035 10.7083 20.9167 10.7083H29.6667C30.0799 10.7083 30.4262 10.8481 30.7057 11.1276C30.9852 11.4071 31.125 11.7535 31.125 12.1667C31.125 12.5799 30.9852 12.9262 30.7057 13.2057C30.4262 13.4852 30.0799 13.625 29.6667 13.625H20.9167ZM20.9167 7.79167C20.5035 7.79167 20.1571 7.65191 19.8776 7.3724C19.5981 7.09288 19.4583 6.74653 19.4583 6.33333C19.4583 5.92014 19.5981 5.57378 19.8776 5.29427C20.1571 5.01476 20.5035 4.875 20.9167 4.875H22.375C22.7882 4.875 23.1346 5.01476 23.4141 5.29427C23.6936 5.57378 23.8333 5.92014 23.8333 6.33333C23.8333 6.74653 23.6936 7.09288 23.4141 7.3724C23.1346 7.65191 22.7882 7.79167 22.375 7.79167H20.9167ZM28.2083 31.125C27.7951 31.125 27.4488 30.9852 27.1693 30.7057C26.8898 30.4262 26.75 30.0799 26.75 29.6667C26.75 29.2535 26.8898 28.9071 27.1693 28.6276C27.4488 28.3481 27.7951 28.2083 28.2083 28.2083H29.6667C30.0799 28.2083 30.4262 28.3481 30.7057 28.6276C30.9852 28.9071 31.125 29.2535 31.125 29.6667C31.125 30.0799 30.9852 30.4262 30.7057 30.7057C30.4262 30.9852 30.0799 31.125 29.6667 31.125H28.2083ZM28.2083 7.79167C27.7951 7.79167 27.4488 7.65191 27.1693 7.3724C26.8898 7.09288 26.75 6.74653 26.75 6.33333C26.75 5.92014 26.8898 5.57378 27.1693 5.29427C27.4488 5.01476 27.7951 4.875 28.2083 4.875H29.6667C30.0799 4.875 30.4262 5.01476 30.7057 5.29427C30.9852 5.57378 31.125 5.92014 31.125 6.33333C31.125 6.74653 30.9852 7.09288 30.7057 7.3724C30.4262 7.65191 30.0799 7.79167 29.6667 7.79167H28.2083Z" fill="black" />
                                    </g>
                                </svg>
                            </div>
                            <div class="asw-action-desc">
                                <span class="asw-action-desc-title" data-ap-translate="ADHD PROFILE TITLE">ADHD Friendly Profile</span>
                                <span class="asw-action-desc-desc" data-ap-translate="ADHD PROFILE HEAD">More focus & fewer distractions</span>
                            </div>
                        </div>
                        <div class="asw-action-heading-right">
                            <label class="asw-switch">
                                <input type="checkbox" onchange="toggleADHD(event)">
                                <span class="asw-switch-off">
                                    <span data-ap-translate="OFF">OFF</span>
                                </span>
                                <span class="asw-switch-on">
                                    <span data-ap-translate="ON">ON</span>
                                </span>
                            </label>
                        </div>
                    </div>
                    <div class="asw-action-description" data-ap-translate="ADHD PROFILE DESC">
                        This profile significantly reduces distractions, to help people with ADHD and Neurodevelopmental disorders browse, read, and focus on the essential elements of the website more easily.
                    </div>
                </div>
                <div class="asw-action">
                    <div class="asw-action-heading">
                        <div class="asw-action-heading-left">
                            <div class="asw-action-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none">
                                    <mask id="mask0_949_184" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="36" height="36">
                                        <rect x="0.5" y="0.5" width="35" height="35" fill="#D9D9D9" />
                                    </mask>
                                    <g mask="url(#mask0_949_184)">
                                        <path d="M18 20.9167C17.1979 20.9167 16.5113 20.6311 15.9401 20.0599C15.3689 19.4887 15.0833 18.8021 15.0833 18C15.0833 17.1979 15.3689 16.5113 15.9401 15.9401C16.5113 15.3689 17.1979 15.0833 18 15.0833C18.8021 15.0833 19.4887 15.3689 20.0599 15.9401C20.6311 16.5113 20.9167 17.1979 20.9167 18C20.9167 18.8021 20.6311 19.4887 20.0599 20.0599C19.4887 20.6311 18.8021 20.9167 18 20.9167ZM16.5417 10.7083V6.33333C16.5417 5.92014 16.6814 5.57378 16.9609 5.29427C17.2405 5.01476 17.5868 4.875 18 4.875C18.4132 4.875 18.7596 5.01476 19.0391 5.29427C19.3186 5.57378 19.4583 5.92014 19.4583 6.33333V10.7083C19.4583 11.1215 19.3186 11.4679 19.0391 11.7474C18.7596 12.0269 18.4132 12.1667 18 12.1667C17.5868 12.1667 17.2405 12.0269 16.9609 11.7474C16.6814 11.4679 16.5417 11.1215 16.5417 10.7083ZM16.5417 29.6667V25.2917C16.5417 24.8785 16.6814 24.5321 16.9609 24.2526C17.2405 23.9731 17.5868 23.8333 18 23.8333C18.4132 23.8333 18.7596 23.9731 19.0391 24.2526C19.3186 24.5321 19.4583 24.8785 19.4583 25.2917V29.6667C19.4583 30.0799 19.3186 30.4262 19.0391 30.7057C18.7596 30.9852 18.4132 31.125 18 31.125C17.5868 31.125 17.2405 30.9852 16.9609 30.7057C16.6814 30.4262 16.5417 30.0799 16.5417 29.6667ZM25.2917 16.5417H29.6667C30.0799 16.5417 30.4262 16.6814 30.7057 16.9609C30.9852 17.2405 31.125 17.5868 31.125 18C31.125 18.4132 30.9852 18.7596 30.7057 19.0391C30.4262 19.3186 30.0799 19.4583 29.6667 19.4583H25.2917C24.8785 19.4583 24.5321 19.3186 24.2526 19.0391C23.9731 18.7596 23.8333 18.4132 23.8333 18C23.8333 17.5868 23.9731 17.2405 24.2526 16.9609C24.5321 16.6814 24.8785 16.5417 25.2917 16.5417ZM6.33333 16.5417H10.7083C11.1215 16.5417 11.4679 16.6814 11.7474 16.9609C12.0269 17.2405 12.1667 17.5868 12.1667 18C12.1667 18.4132 12.0269 18.7596 11.7474 19.0391C11.4679 19.3186 11.1215 19.4583 10.7083 19.4583H6.33333C5.92014 19.4583 5.57378 19.3186 5.29427 19.0391C5.01476 18.7596 4.875 18.4132 4.875 18C4.875 17.5868 5.01476 17.2405 5.29427 16.9609C5.57378 16.6814 5.92014 16.5417 6.33333 16.5417Z" fill="black" />
                                    </g>
                                </svg>
                            </div>
                            <div class="asw-action-desc">
                                <span class="asw-action-desc-title" data-ap-translate="COGNITIVE PROFILE TITLE">Cognitive Disability Profile</span>
                                <span class="asw-action-desc-desc" data-ap-translate="COGNITIVE PROFILE HEAD">Assists with reading & focusing</span>
                            </div>
                        </div>
                        <div class="asw-action-heading-right">
                            <label class="asw-switch">
                                <input class="asw-action-switch-toggle" type="checkbox" onchange="toggleCognition(event)">
                                <span class="asw-switch-off">
                                    <span data-ap-translate="OFF">OFF</span>
                                </span>
                                <span class="asw-switch-on">
                                    <span data-ap-translate="ON">ON</span>
                                </span>
                            </label>
                        </div>
                    </div>
                    <div class="asw-action-description" data-ap-translate="COGNITIVE PROFILE DESC">
                        This profile provides various assistive features to help users with cognitive disabilities such as Autism, Dyslexia, CVA, and others, to focus on the essential elements of the website more easily.
                    </div>
                </div>
            </div>
        </div>
        <div class="asw-card ap-border-bottom">
            <p class="ap-fw-400 ap-font-18" data-ap-translate="CONTENT SETTINGS">Content Settings</p>
            <div class="ap-setting ap-gray-bg ap-setting-full" style="padding-block: 20px !important; flex-wrap: wrap;">
                <div class="ap-setting-full-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_884_405" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.572906" width="35" height="34.8542" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_884_405)">
                            <path d="M12.3958 29.618C11.7882 29.618 11.2717 29.4062 10.8463 28.9827C10.421 28.5591 10.2083 28.0448 10.2083 27.4397V10.7387H5.10413C4.49649 10.7387 3.97999 10.5269 3.55465 10.1033C3.1293 9.67976 2.91663 9.16542 2.91663 8.56031C2.91663 7.95521 3.1293 7.44086 3.55465 7.01729C3.97999 6.59371 4.49649 6.38193 5.10413 6.38193H19.6875C20.2951 6.38193 20.8116 6.59371 21.2369 7.01729C21.6623 7.44086 21.875 7.95521 21.875 8.56031C21.875 9.16542 21.6623 9.67976 21.2369 10.1033C20.8116 10.5269 20.2951 10.7387 19.6875 10.7387H14.5833V27.4397C14.5833 28.0448 14.3706 28.5591 13.9453 28.9827C13.5199 29.4062 13.0034 29.618 12.3958 29.618ZM25.5208 29.618C24.9132 29.618 24.3967 29.4062 23.9713 28.9827C23.546 28.5591 23.3333 28.0448 23.3333 27.4397V18H21.1458C20.5382 18 20.0217 17.7882 19.5963 17.3646C19.171 16.941 18.9583 16.4267 18.9583 15.8216C18.9583 15.2165 19.171 14.7021 19.5963 14.2786C20.0217 13.855 20.5382 13.6432 21.1458 13.6432H29.8958C30.5034 13.6432 31.0199 13.855 31.4453 14.2786C31.8706 14.7021 32.0833 15.2165 32.0833 15.8216C32.0833 16.4267 31.8706 16.941 31.4453 17.3646C31.0199 17.7882 30.5034 18 29.8958 18H27.7083V27.4397C27.7083 28.0448 27.4956 28.5591 27.0703 28.9827C26.6449 29.4062 26.1284 29.618 25.5208 29.618Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="FONT SCALE">Font Scale</span>
                </div>
                <div class="ap-range-input-wrapper">
                    <input class="ap-range-input" id="apFontRangeSlider" type="range" min="0.5" max="1.5" step="0.1" onchange="adjustFontSize(event)">
                </div>
                <div class="ap-range-value-wrapper">
                    <span class="ap-range-value" id="apFontRangeValue">+0</span>
                </div>
            </div>

            <div class="ap-setting-half">
                <div class="ap-setting ap-gray-bg" id="btnLineHeight" onclick="adjustLineHeight(1)">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_912_12" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_912_12)">
                            <path d="M7.29162 11.9479L5.97912 13.224C5.71176 13.4913 5.37756 13.625 4.97652 13.625C4.57548 13.625 4.22912 13.4792 3.93746 13.1875C3.67009 12.9201 3.53641 12.5799 3.53641 12.1667C3.53641 11.7535 3.67009 11.4132 3.93746 11.1458L7.72912 7.35417C7.87496 7.20833 8.03294 7.10503 8.20308 7.04427C8.37322 6.98351 8.55551 6.95312 8.74996 6.95312C8.9444 6.95312 9.12669 6.98351 9.29683 7.04427C9.46697 7.10503 9.62496 7.20833 9.77079 7.35417L13.5625 11.1458C13.8298 11.4132 13.9696 11.7474 13.9817 12.1484C13.9939 12.5495 13.8541 12.8958 13.5625 13.1875C13.2951 13.4549 12.9609 13.5946 12.5599 13.6068C12.1588 13.6189 11.8125 13.4913 11.5208 13.224L10.2083 11.9479V24.0521L11.5208 22.776C11.7882 22.5087 12.1224 22.375 12.5234 22.375C12.9244 22.375 13.2708 22.5208 13.5625 22.8125C13.8298 23.0799 13.9635 23.4201 13.9635 23.8333C13.9635 24.2465 13.8298 24.5868 13.5625 24.8542L9.77079 28.6458C9.62496 28.7917 9.46697 28.895 9.29683 28.9557C9.12669 29.0165 8.9444 29.0469 8.74996 29.0469C8.55551 29.0469 8.37322 29.0165 8.20308 28.9557C8.03294 28.895 7.87496 28.7917 7.72912 28.6458L3.93746 24.8542C3.67009 24.5868 3.53034 24.2526 3.51819 23.8516C3.50603 23.4505 3.64579 23.1042 3.93746 22.8125C4.20482 22.5451 4.53902 22.4054 4.94006 22.3932C5.3411 22.3811 5.68746 22.5087 5.97912 22.776L7.29162 24.0521V11.9479ZM18.9583 28.2083C18.5451 28.2083 18.1987 28.0686 17.9192 27.7891C17.6397 27.5095 17.5 27.1632 17.5 26.75C17.5 26.3368 17.6397 25.9904 17.9192 25.7109C18.1987 25.4314 18.5451 25.2917 18.9583 25.2917H30.625C31.0382 25.2917 31.3845 25.4314 31.664 25.7109C31.9435 25.9904 32.0833 26.3368 32.0833 26.75C32.0833 27.1632 31.9435 27.5095 31.664 27.7891C31.3845 28.0686 31.0382 28.2083 30.625 28.2083H18.9583ZM18.9583 19.4583C18.5451 19.4583 18.1987 19.3186 17.9192 19.0391C17.6397 18.7595 17.5 18.4132 17.5 18C17.5 17.5868 17.6397 17.2405 17.9192 16.9609C18.1987 16.6814 18.5451 16.5417 18.9583 16.5417H30.625C31.0382 16.5417 31.3845 16.6814 31.664 16.9609C31.9435 17.2405 32.0833 17.5868 32.0833 18C32.0833 18.4132 31.9435 18.7595 31.664 19.0391C31.3845 19.3186 31.0382 19.4583 30.625 19.4583H18.9583ZM18.9583 10.7083C18.5451 10.7083 18.1987 10.5686 17.9192 10.2891C17.6397 10.0095 17.5 9.66319 17.5 9.25C17.5 8.83681 17.6397 8.49045 17.9192 8.21094C18.1987 7.93142 18.5451 7.79167 18.9583 7.79167H30.625C31.0382 7.79167 31.3845 7.93142 31.664 8.21094C31.9435 8.49045 32.0833 8.83681 32.0833 9.25C32.0833 9.66319 31.9435 10.0095 31.664 10.2891C31.3845 10.5686 31.0382 10.7083 30.625 10.7083H18.9583Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="LINE SPACING">Increase Line Spacing</span>
                </div>
                <div class="ap-setting ap-gray-bg" id="btnLetterSpacing" onclick="adjustLetterSpacing(0.1)">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_884_626" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_884_626)">
                            <path d="M8.74996 32.5833L2.91663 26.75L8.74996 20.9167L10.8281 22.9583L8.49475 25.2917H26.5052L24.2083 22.9583L26.25 20.9167L32.0833 26.75L26.25 32.5833L24.1718 30.5417L26.5052 28.2083H8.49475L10.7916 30.5417L8.74996 32.5833ZM10.0625 19.4583L16.0416 3.41666H18.9583L24.9375 19.4583H22.1666L20.7812 15.375H14.2916L12.8333 19.4583H10.0625ZM15.0937 13.0417H19.9062L17.5729 6.40624H17.427L15.0937 13.0417Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="LETTER SPACING">Increase Letter Spacing</span>
                </div>
            </div>

            <div class="ap-setting-half">
                <div class="ap-setting ap-gray-bg" id="btnDyslexicFont" onclick="enableDyslexicFont()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_912_232" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_912_232)">
                            <path d="M20.5625 28.5L27.7812 21.2812C28.0486 21.0139 28.3889 20.8802 28.8021 20.8802C29.2152 20.8802 29.5555 21.0139 29.8229 21.2812C30.0902 21.5486 30.2239 21.8889 30.2239 22.3021C30.2239 22.7153 30.0902 23.0556 29.8229 23.3229L22.6406 30.5052C22.3489 30.7969 22.0208 31.0156 21.6562 31.1615C21.2916 31.3073 20.9271 31.3802 20.5625 31.3802C20.1979 31.3802 19.8333 31.3073 19.4687 31.1615C19.1041 31.0156 18.776 30.7969 18.4843 30.5052L15.3854 27.4063C15.118 27.1389 14.9843 26.7986 14.9843 26.3854C14.9843 25.9722 15.118 25.6319 15.3854 25.3646C15.6527 25.0972 15.993 24.9635 16.4062 24.9635C16.8194 24.9635 17.1597 25.0972 17.4271 25.3646L20.5625 28.5ZM9.26038 19.0208L7.91143 22.849C7.7899 23.1406 7.60761 23.3776 7.36455 23.5599C7.1215 23.7422 6.84198 23.8333 6.52601 23.8333C5.99129 23.8333 5.57809 23.6146 5.28643 23.1771C4.99476 22.7396 4.94615 22.2778 5.14059 21.7917L11.0468 5.93229C11.1684 5.61632 11.3689 5.36111 11.6484 5.16667C11.9279 4.97222 12.2378 4.875 12.5781 4.875H13.7448C14.085 4.875 14.3949 4.97222 14.6744 5.16667C14.954 5.36111 15.1545 5.61632 15.276 5.93229L21.1823 21.7552C21.3767 22.2656 21.322 22.7396 21.0182 23.1771C20.7144 23.6146 20.283 23.8333 19.7239 23.8333C19.3836 23.8333 19.0798 23.7361 18.8125 23.5417C18.5451 23.3472 18.3507 23.092 18.2291 22.776L16.9166 19.0208H9.26038ZM10.2812 16.25H15.9687L13.1979 8.375H13.0521L10.2812 16.25Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="DYSLEXIC FONT">Use Dyslexic Font</span>
                </div>
                <div class="ap-setting ap-gray-bg" id="btnFontWeight" onclick="adjustFontWeight(400)">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_912_18" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_912_18)">
                            <path d="M12.8334 28.2084C12.0313 28.2084 11.3447 27.9228 10.7735 27.3516C10.2023 26.7804 9.91675 26.0938 9.91675 25.2917V10.7084C9.91675 9.90627 10.2023 9.21964 10.7735 8.64846C11.3447 8.07728 12.0313 7.79169 12.8334 7.79169H17.974C19.5539 7.79169 21.0122 8.2778 22.349 9.25002C23.6858 10.2222 24.3542 11.5712 24.3542 13.2969C24.3542 14.5365 24.0747 15.4905 23.5157 16.1589C22.9567 16.8273 22.4341 17.3073 21.948 17.599C22.5556 17.8663 23.2301 18.3646 23.9714 19.0938C24.7128 19.8229 25.0834 20.9167 25.0834 22.375C25.0834 24.5382 24.2935 26.0512 22.7136 26.9141C21.1338 27.7769 19.6511 28.2084 18.2657 28.2084H12.8334ZM14.3282 24.125H18.1199C19.2865 24.125 19.9975 23.8273 20.2527 23.2318C20.5079 22.6363 20.6355 22.2049 20.6355 21.9375C20.6355 21.6702 20.5079 21.2387 20.2527 20.6432C19.9975 20.0478 19.2501 19.75 18.0105 19.75H14.3282V24.125ZM14.3282 15.8125H17.7188C18.5209 15.8125 19.1042 15.6059 19.4688 15.1927C19.8334 14.7795 20.0157 14.3177 20.0157 13.8073C20.0157 13.224 19.8091 12.75 19.3959 12.3854C18.9827 12.0209 18.448 11.8386 17.7917 11.8386H14.3282V15.8125Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="FONT WEIGHT">Increase Font Weight</span>
                </div>
            </div>

            <div class="ap-setting ap-gray-bg ap-setting-full">
                <div class="ap-setting-full-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_884_713" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.572876" width="35" height="34.8542" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_884_713)">
                            <path d="M7.29171 28.1658C6.87851 28.1658 6.53216 28.0266 6.25264 27.7482C5.97313 27.4699 5.83337 27.125 5.83337 26.7135C5.83337 26.302 5.97313 25.9571 6.25264 25.6788C6.53216 25.4004 6.87851 25.2612 7.29171 25.2612H18.9584C19.3716 25.2612 19.7179 25.4004 19.9974 25.6788C20.277 25.9571 20.4167 26.302 20.4167 26.7135C20.4167 27.125 20.277 27.4699 19.9974 27.7482C19.7179 28.0266 19.3716 28.1658 18.9584 28.1658H7.29171ZM7.29171 22.3567C6.87851 22.3567 6.53216 22.2176 6.25264 21.9392C5.97313 21.6609 5.83337 21.316 5.83337 20.9045C5.83337 20.493 5.97313 20.1481 6.25264 19.8697C6.53216 19.5914 6.87851 19.4522 7.29171 19.4522H27.7084C28.1216 19.4522 28.4679 19.5914 28.7474 19.8697C29.027 20.1481 29.1667 20.493 29.1667 20.9045C29.1667 21.316 29.027 21.6609 28.7474 21.9392C28.4679 22.2176 28.1216 22.3567 27.7084 22.3567H7.29171ZM7.29171 16.5477C6.87851 16.5477 6.53216 16.4085 6.25264 16.1302C5.97313 15.8518 5.83337 15.5069 5.83337 15.0955C5.83337 14.684 5.97313 14.3391 6.25264 14.0607C6.53216 13.7824 6.87851 13.6432 7.29171 13.6432H27.7084C28.1216 13.6432 28.4679 13.7824 28.7474 14.0607C29.027 14.3391 29.1667 14.684 29.1667 15.0955C29.1667 15.5069 29.027 15.8518 28.7474 16.1302C28.4679 16.4085 28.1216 16.5477 27.7084 16.5477H7.29171ZM7.29171 10.7387C6.87851 10.7387 6.53216 10.5995 6.25264 10.3212C5.97313 10.0428 5.83337 9.6979 5.83337 9.28642C5.83337 8.87495 5.97313 8.53004 6.25264 8.25169C6.53216 7.97334 6.87851 7.83417 7.29171 7.83417H27.7084C28.1216 7.83417 28.4679 7.97334 28.7474 8.25169C29.027 8.53004 29.1667 8.87495 29.1667 9.28642C29.1667 9.6979 29.027 10.0428 28.7474 10.3212C28.4679 10.5995 28.1216 10.7387 27.7084 10.7387H7.29171Z" fill="black" />
                        </g>
                    </svg>

                    <span class="ap-font-18 ap-fw-400" data-ap-translate="TEXT ALIGN">Text<br>Alignment</span>
                </div>

                <div class="ap-setting-buttons">
                    <div class="ap-setting-button" id="btnTextAlignLeft" onclick="adjustTextAlignLeft()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 35 35" fill="none">
                            <mask id="mask0_926_482" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="35">
                                <rect y="0.145844" width="35" height="34.8542" fill="#D9D9D9" />
                            </mask>
                            <g mask="url(#mask0_926_482)">
                                <path d="M7.29159 27.7387C6.87839 27.7387 6.53204 27.5996 6.25252 27.3212C5.97301 27.0429 5.83325 26.6979 5.83325 26.2865C5.83325 25.875 5.97301 25.5301 6.25252 25.2517C6.53204 24.9734 6.87839 24.8342 7.29159 24.8342H18.9583C19.3714 24.8342 19.7178 24.9734 19.9973 25.2517C20.2768 25.5301 20.4166 25.875 20.4166 26.2865C20.4166 26.6979 20.2768 27.0429 19.9973 27.3212C19.7178 27.5996 19.3714 27.7387 18.9583 27.7387H7.29159ZM7.29159 21.9297C6.87839 21.9297 6.53204 21.7905 6.25252 21.5122C5.97301 21.2338 5.83325 20.8889 5.83325 20.4774C5.83325 20.066 5.97301 19.7211 6.25252 19.4427C6.53204 19.1644 6.87839 19.0252 7.29159 19.0252H27.7083C28.1214 19.0252 28.4678 19.1644 28.7473 19.4427C29.0268 19.7211 29.1666 20.066 29.1666 20.4774C29.1666 20.8889 29.0268 21.2338 28.7473 21.5122C28.4678 21.7905 28.1214 21.9297 27.7083 21.9297H7.29159ZM7.29159 16.1207C6.87839 16.1207 6.53204 15.9815 6.25252 15.7032C5.97301 15.4248 5.83325 15.0799 5.83325 14.6684C5.83325 14.2569 5.97301 13.912 6.25252 13.6337C6.53204 13.3553 6.87839 13.2162 7.29159 13.2162H27.7083C28.1214 13.2162 28.4678 13.3553 28.7473 13.6337C29.0268 13.912 29.1666 14.2569 29.1666 14.6684C29.1666 15.0799 29.0268 15.4248 28.7473 15.7032C28.4678 15.9815 28.1214 16.1207 27.7083 16.1207H7.29159ZM7.29159 10.3116C6.87839 10.3116 6.53204 10.1725 6.25252 9.89412C5.97301 9.61578 5.83325 9.27086 5.83325 8.85939C5.83325 8.44792 5.97301 8.10301 6.25252 7.82466C6.53204 7.54631 6.87839 7.40714 7.29159 7.40714H27.7083C28.1214 7.40714 28.4678 7.54631 28.7473 7.82466C29.0268 8.10301 29.1666 8.44792 29.1666 8.85939C29.1666 9.27086 29.0268 9.61578 28.7473 9.89412C28.4678 10.1725 28.1214 10.3116 27.7083 10.3116H7.29159Z" fill="black" />
                            </g>
                        </svg>
                        <span data-ap-translate="LEFT">Left</span>
                    </div>
                    <div class="ap-setting-button" id="btnTextAlignCenter" onclick="adjustTextAlignCenter()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                            <mask id="mask0_884_730" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="25" height="25">
                                <rect x="0.219604" y="0.5" width="24" height="24" fill="#D9D9D9" />
                            </mask>
                            <g mask="url(#mask0_884_730)">
                                <path d="M3.2196 21.5V19.5H21.2196V21.5H3.2196ZM7.2196 17.5V15.5H17.2196V17.5H7.2196ZM3.2196 13.5V11.5H21.2196V13.5H3.2196ZM7.2196 9.5V7.5H17.2196V9.5H7.2196ZM3.2196 5.5V3.5H21.2196V5.5H3.2196Z" fill="black" />
                            </g>
                        </svg>
                        <span data-ap-translate="CENTER">Center</span>
                    </div>
                    <div class="ap-setting-button" id="btnTextAlignRight" onclick="adjustTextAlignRight()">
                        <svg xmlns=" http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                            <mask id="mask0_884_736" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="25" height="25">
                                <rect x="0.406494" y="0.5" width="24" height="24" fill="#D9D9D9" />
                            </mask>
                            <g mask="url(#mask0_884_736)">
                                <path d="M3.40649 5.5V3.5H21.4065V5.5H3.40649ZM9.40649 9.5V7.5H21.4065V9.5H9.40649ZM3.40649 13.5V11.5H21.4065V13.5H3.40649ZM9.40649 17.5V15.5H21.4065V17.5H9.40649ZM3.40649 21.5V19.5H21.4065V21.5H3.40649Z" fill="black" />
                            </g>
                        </svg>
                        <span data-ap-translate="RIGHT">Right</span>
                    </div>
                </div>
            </div>

            <div class="ap-setting ap-gray-bg ap-setting-full">
                <div class="ap-setting-full-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_884_764" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.572876" width="35" height="34.8542" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_884_764)">
                            <path d="M17.5 32.5226C15.4826 32.5226 13.5868 32.1413 11.8125 31.3789C10.0382 30.6165 8.49475 29.5817 7.18225 28.2747C5.86975 26.9677 4.83069 25.4307 4.06506 23.6638C3.29944 21.8969 2.91663 20.0089 2.91663 18C2.91663 15.991 3.29944 14.1031 4.06506 12.3362C4.83069 10.5693 5.86975 9.0323 7.18225 7.72527C8.49475 6.41824 10.0382 5.3835 11.8125 4.62107C13.5868 3.85863 15.4826 3.47742 17.5 3.47742C19.5173 3.47742 21.4132 3.85863 23.1875 4.62107C24.9618 5.3835 26.5052 6.41824 27.8177 7.72527C29.1302 9.0323 30.1692 10.5693 30.9349 12.3362C31.7005 14.1031 32.0833 15.991 32.0833 18C32.0833 20.0089 31.7005 21.8969 30.9349 23.6638C30.1692 25.4307 29.1302 26.9677 27.8177 28.2747C26.5052 29.5817 24.9618 30.6165 23.1875 31.3789C21.4132 32.1413 19.5173 32.5226 17.5 32.5226ZM18.9583 29.5091C21.8507 29.1461 24.2751 27.8814 26.2317 25.7151C28.1883 23.5488 29.1666 20.9771 29.1666 18C29.1666 15.0229 28.1883 12.4512 26.2317 10.2849C24.2751 8.11859 21.8507 6.85391 18.9583 6.49085V29.5091Z" fill="black" />
                        </g>
                    </svg>

                    <span class="ap-font-18 ap-fw-400" data-ap-translate="CONTRAST">Contrast<br>Mode</span>
                </div>

                <div class="ap-setting-buttons">
                    <div class="ap-setting-button" id="btnContrast" onclick="adjustContrast()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                            <mask id="mask0_926_495" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="25">
                                <rect y="0.854156" width="24" height="24" fill="#D9D9D9" />
                            </mask>
                            <g mask="url(#mask0_926_495)">
                                <path d="M12 21.8542C9.5 21.8542 7.375 20.9792 5.625 19.2292C3.875 17.4792 3 15.3542 3 12.8542C3 10.3542 3.875 8.22916 5.625 6.47916C7.375 4.72916 9.5 3.85416 12 3.85416C12.2333 3.85416 12.4625 3.86249 12.6875 3.87916C12.9125 3.89582 13.1333 3.92082 13.35 3.95416C12.6667 4.43749 12.1208 5.06666 11.7125 5.84166C11.3042 6.61666 11.1 7.45416 11.1 8.35416C11.1 9.85416 11.625 11.1292 12.675 12.1792C13.725 13.2292 15 13.7542 16.5 13.7542C17.4167 13.7542 18.2583 13.55 19.025 13.1417C19.7917 12.7333 20.4167 12.1875 20.9 11.5042C20.9333 11.7208 20.9583 11.9417 20.975 12.1667C20.9917 12.3917 21 12.6208 21 12.8542C21 15.3542 20.125 17.4792 18.375 19.2292C16.625 20.9792 14.5 21.8542 12 21.8542ZM12 19.8542C13.4667 19.8542 14.7833 19.45 15.95 18.6417C17.1167 17.8333 17.9667 16.7792 18.5 15.4792C18.1667 15.5625 17.8333 15.6292 17.5 15.6792C17.1667 15.7292 16.8333 15.7542 16.5 15.7542C14.45 15.7542 12.7042 15.0333 11.2625 13.5917C9.82083 12.15 9.1 10.4042 9.1 8.35416C9.1 8.02082 9.125 7.68749 9.175 7.35416C9.225 7.02082 9.29167 6.68749 9.375 6.35416C8.075 6.88749 7.02083 7.73749 6.2125 8.90416C5.40417 10.0708 5 11.3875 5 12.8542C5 14.7875 5.68333 16.4375 7.05 17.8042C8.41667 19.1708 10.0667 19.8542 12 19.8542Z" fill="black" />
                            </g>
                        </svg>
                        <span data-ap-translate="DARK">Dark</span>
                    </div>
                    <div class="ap-setting-button" id="btnLightContrast" onclick="adjustLightContrast()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                            <mask id="mask0_884_776" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="25" height="25">
                                <rect x="0.219727" y="0.5" width="24" height="24" fill="#D9D9D9" />
                            </mask>
                            <g mask="url(#mask0_884_776)">
                                <path d="M12.2197 15.5C13.0531 15.5 13.7614 15.2083 14.3447 14.625C14.9281 14.0417 15.2197 13.3333 15.2197 12.5C15.2197 11.6667 14.9281 10.9583 14.3447 10.375C13.7614 9.79167 13.0531 9.5 12.2197 9.5C11.3864 9.5 10.6781 9.79167 10.0947 10.375C9.51139 10.9583 9.21973 11.6667 9.21973 12.5C9.21973 13.3333 9.51139 14.0417 10.0947 14.625C10.6781 15.2083 11.3864 15.5 12.2197 15.5ZM12.2197 17.5C10.8364 17.5 9.65723 17.0125 8.68223 16.0375C7.70723 15.0625 7.21973 13.8833 7.21973 12.5C7.21973 11.1167 7.70723 9.9375 8.68223 8.9625C9.65723 7.9875 10.8364 7.5 12.2197 7.5C13.6031 7.5 14.7822 7.9875 15.7572 8.9625C16.7322 9.9375 17.2197 11.1167 17.2197 12.5C17.2197 13.8833 16.7322 15.0625 15.7572 16.0375C14.7822 17.0125 13.6031 17.5 12.2197 17.5ZM5.21973 13.5H1.21973V11.5H5.21973V13.5ZM23.2197 13.5H19.2197V11.5H23.2197V13.5ZM11.2197 5.5V1.5H13.2197V5.5H11.2197ZM11.2197 23.5V19.5H13.2197V23.5H11.2197ZM6.61973 8.25L4.09473 5.825L5.51973 4.35L7.91973 6.85L6.61973 8.25ZM18.9197 20.65L16.4947 18.125L17.8197 16.75L20.3447 19.175L18.9197 20.65ZM16.4697 6.9L18.8947 4.375L20.3697 5.8L17.8697 8.2L16.4697 6.9ZM4.06973 19.2L6.59473 16.775L7.96973 18.1L5.54473 20.625L4.06973 19.2Z" fill="black" />
                            </g>
                        </svg>
                        <span data-ap-translate="LIGHT">Light</span>
                    </div>
                    <div class="ap-setting-button" id="btnHighContrast" onclick="adjustHighContrast()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                            <mask id="mask0_884_782" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="25" height="25">
                                <rect x="0.406494" y="0.5" width="24" height="24" fill="#D9D9D9" />
                            </mask>
                            <g mask="url(#mask0_884_782)">
                                <path d="M12.4065 22.5C11.0232 22.5 9.72316 22.2375 8.50649 21.7125C7.28983 21.1875 6.23149 20.475 5.33149 19.575C4.43149 18.675 3.71899 17.6167 3.19399 16.4C2.66899 15.1833 2.40649 13.8833 2.40649 12.5C2.40649 11.1167 2.66899 9.81667 3.19399 8.6C3.71899 7.38333 4.43149 6.325 5.33149 5.425C6.23149 4.525 7.28983 3.8125 8.50649 3.2875C9.72316 2.7625 11.0232 2.5 12.4065 2.5C13.7898 2.5 15.0898 2.7625 16.3065 3.2875C17.5232 3.8125 18.5815 4.525 19.4815 5.425C20.3815 6.325 21.094 7.38333 21.619 8.6C22.144 9.81667 22.4065 11.1167 22.4065 12.5C22.4065 13.8833 22.144 15.1833 21.619 16.4C21.094 17.6167 20.3815 18.675 19.4815 19.575C18.5815 20.475 17.5232 21.1875 16.3065 21.7125C15.0898 22.2375 13.7898 22.5 12.4065 22.5ZM13.4065 20.425C15.3898 20.175 17.0523 19.3042 18.394 17.8125C19.7357 16.3208 20.4065 14.55 20.4065 12.5C20.4065 10.45 19.7357 8.67917 18.394 7.1875C17.0523 5.69583 15.3898 4.825 13.4065 4.575V20.425Z" fill="black" />
                            </g>
                        </svg>
                        <span data-ap-translate="HIGH">High</span>
                    </div>
                </div>
            </div>

            <div class="ap-setting ap-gray-bg ap-setting-full">
                <div class="ap-setting-full-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_884_809" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.572876" width="35" height="34.8542" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_884_809)">
                            <path d="M12.6145 30.3442L3.64579 21.4128C3.40274 21.1707 3.22045 20.9045 3.09892 20.614C2.97739 20.3236 2.91663 20.021 2.91663 19.7064C2.91663 19.3917 2.97739 19.0892 3.09892 18.7987C3.22045 18.5083 3.40274 18.242 3.64579 18L12.0312 9.68581L9.29683 6.96283C8.98086 6.64818 8.8168 6.27301 8.80465 5.83733C8.79249 5.40165 8.9444 5.01439 9.26038 4.67553C9.57635 4.33667 9.96524 4.16724 10.427 4.16724C10.8888 4.16724 11.2899 4.33667 11.6302 4.67553L25.0104 18C25.2534 18.242 25.4296 18.5083 25.539 18.7987C25.6484 19.0892 25.7031 19.3917 25.7031 19.7064C25.7031 20.021 25.6484 20.3236 25.539 20.614C25.4296 20.9045 25.2534 21.1707 25.0104 21.4128L16.0416 30.3442C15.7986 30.5862 15.5312 30.7677 15.2395 30.8888C14.9479 31.0098 14.6441 31.0703 14.3281 31.0703C14.0121 31.0703 13.7083 31.0098 13.4166 30.8888C13.125 30.7677 12.8576 30.5862 12.6145 30.3442ZM14.3281 11.9731L6.526 19.7427H22.1302L14.3281 11.9731ZM28.875 31.0703C28 31.0703 27.2586 30.7617 26.651 30.1445C26.0434 29.5273 25.7395 28.7709 25.7395 27.8753C25.7395 27.2218 25.9036 26.6046 26.2317 26.0237C26.5599 25.4428 26.9305 24.874 27.3437 24.3173L28.0364 23.4459C28.2552 23.1797 28.5408 23.0405 28.8932 23.0284C29.2456 23.0163 29.5312 23.1434 29.75 23.4096L30.4791 24.3173C30.868 24.874 31.2326 25.4428 31.5729 26.0237C31.9132 26.6046 32.0833 27.2218 32.0833 27.8753C32.0833 28.7709 31.7673 29.5273 31.1354 30.1445C30.5034 30.7617 29.75 31.0703 28.875 31.0703Z" fill="black" />
                        </g>
                    </svg>

                    <span class="ap-font-18 ap-fw-400" data-ap-translate="SATURATION">Color<br>Saturation</span>
                </div>

                <div class="ap-setting-buttons">
                    <div class="ap-setting-button" id="btnHighSaturation" onclick="adjustHighSaturation()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                            <mask id="mask0_926_485" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="25">
                                <rect y="0.854156" width="24" height="24" fill="#D9D9D9" />
                            </mask>
                            <g mask="url(#mask0_926_485)">
                                <path d="M12 22.3542C9.78333 22.3542 7.89583 21.5875 6.3375 20.0542C4.77917 18.5208 4 16.6542 4 14.4542C4 13.4042 4.20417 12.4 4.6125 11.4417C5.02083 10.4833 5.6 9.63749 6.35 8.90416L12 3.35416L17.65 8.90416C18.4 9.63749 18.9792 10.4833 19.3875 11.4417C19.7958 12.4 20 13.4042 20 14.4542C20 16.6542 19.2208 18.5208 17.6625 20.0542C16.1042 21.5875 14.2167 22.3542 12 22.3542Z" fill="black" />
                            </g>
                        </svg>
                        <span data-ap-translate="HIGH">High</span>
                    </div>
                    <div class="ap-setting-button" id="btnLowSaturation" onclick="adjustLowSaturation()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                            <mask id="mask0_884_821" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="25" height="25">
                                <rect x="0.219727" y="0.5" width="24" height="24" fill="#D9D9D9" />
                            </mask>
                            <g mask="url(#mask0_884_821)">
                                <path d="M12.2197 21.5C10.0031 21.5 8.11556 20.7333 6.55723 19.2C4.99889 17.6667 4.21973 15.8 4.21973 13.6C4.21973 12.5167 4.42806 11.5042 4.84473 10.5625C5.26139 9.62083 5.83639 8.78333 6.56973 8.05L12.2197 2.5L17.8697 8.05C18.6031 8.78333 19.1781 9.62083 19.5947 10.5625C20.0114 11.5042 20.2197 12.5167 20.2197 13.6C20.2197 15.8 19.4406 17.6667 17.8822 19.2C16.3239 20.7333 14.4364 21.5 12.2197 21.5ZM6.26973 14.5H18.1197C18.3197 13.3 18.2072 12.275 17.7822 11.425C17.3572 10.575 16.9197 9.93333 16.4697 9.5L12.2197 5.3L7.96973 9.5C7.51973 9.93333 7.07806 10.575 6.64473 11.425C6.21139 12.275 6.08639 13.3 6.26973 14.5Z" fill="black" />
                            </g>
                        </svg>
                        <span data-ap-translate="LOW">Low</span>
                    </div>
                    <div class="ap-setting-button" id="btnMonochrome" onclick="enableMonochrome()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                            <mask id="mask0_884_827" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="25" height="25">
                                <rect x="0.406494" y="0.5" width="24" height="24" fill="#D9D9D9" />
                            </mask>
                            <g mask="url(#mask0_884_827)">
                                <path d="M12.4065 21.5C10.1898 21.5 8.30233 20.7292 6.74399 19.1875C5.18566 17.6458 4.40649 15.7833 4.40649 13.6C4.40649 12.5 4.61483 11.4833 5.03149 10.55C5.44816 9.61667 6.02316 8.78333 6.75649 8.05L12.4065 2.5L18.0565 8.05C18.7898 8.78333 19.3648 9.61667 19.7815 10.55C20.1982 11.4833 20.4065 12.5 20.4065 13.6C20.4065 15.7833 19.6273 17.6458 18.069 19.1875C16.5107 20.7292 14.6232 21.5 12.4065 21.5ZM12.4065 19.5V5.3L8.15649 9.5C7.57316 10.05 7.13566 10.6708 6.84399 11.3625C6.55233 12.0542 6.40649 12.8 6.40649 13.6C6.40649 15.2167 6.98983 16.6042 8.15649 17.7625C9.32316 18.9208 10.7398 19.5 12.4065 19.5Z" fill="black" />
                            </g>
                        </svg>
                        <span data-ap-translate="BLACK & WHITE">Black & White</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="asw-card ap-border-bottom ap-settings">
            <p class="ap-fw-400 ap-font-18" data-ap-translate="BROWSING SETTINGS">Browsing Settings</p>
            <div class="ap-setting ap-gray-bg ap-setting-full" style="padding-block: 20px !important; flex-wrap: wrap;">
                <div class="ap-setting-full-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_884_1093" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.572876" width="35" height="34.8542" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_884_1093)">
                            <path d="M22.0938 31.6148C21.5347 31.8811 20.9757 31.9113 20.4167 31.7056C19.8576 31.4999 19.4444 31.1186 19.1771 30.5619L14.8021 21.1949L11.4115 25.9147C10.9983 26.4956 10.4514 26.6772 9.77083 26.4593C9.09028 26.2415 8.75 25.7816 8.75 25.0797V6.45448C8.75 5.84937 9.02344 5.41369 9.57031 5.14745C10.1172 4.8812 10.6337 4.94171 11.1198 5.32898L25.849 16.8744C26.408 17.2859 26.572 17.8184 26.3411 18.4719C26.1102 19.1254 25.6424 19.4522 24.9375 19.4522H18.8125L23.151 28.7103C23.4184 29.267 23.4488 29.8237 23.2422 30.3804C23.0356 30.9371 22.6528 31.3486 22.0938 31.6148Z" fill="#1C1B1F" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="CURSOR">Cursor Size</span>
                </div>
                <div class="ap-range-input-wrapper">
                    <input class="ap-range-input" id="apCursorSlider" type="range" min="0" max="1" value="0" onchange="enableBigCursor(false, event)">
                </div>
                <div class="ap-range-value-wrapper">
                    <span class="ap-range-value" id="apCursorValue">+0</span>
                </div>
            </div>

            <div class="ap-setting-half">
                <div class="ap-setting ap-gray-bg" id="btnMagnifyText" onclick="magnifyText()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_884_978" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_884_978)">
                            <path d="M28.5833 31.125L19.3958 21.9375C18.6667 22.5208 17.8281 22.9826 16.8802 23.3229C15.9323 23.6632 14.9236 23.8333 13.8542 23.8333C11.2049 23.8333 8.96267 22.9158 7.1276 21.0807C5.29253 19.2457 4.375 17.0035 4.375 14.3542C4.375 11.7049 5.29253 9.46267 7.1276 7.6276C8.96267 5.79253 11.2049 4.875 13.8542 4.875C16.5035 4.875 18.7457 5.79253 20.5807 7.6276C22.4158 9.46267 23.3333 11.7049 23.3333 14.3542C23.3333 15.4236 23.1632 16.4323 22.8229 17.3802C22.4826 18.3281 22.0208 19.1667 21.4375 19.8958L30.625 29.0833L28.5833 31.125ZM13.8542 20.9167C15.6771 20.9167 17.2266 20.2786 18.5026 19.0026C19.7786 17.7266 20.4167 16.1771 20.4167 14.3542C20.4167 12.5312 19.7786 10.9818 18.5026 9.70573C17.2266 8.42969 15.6771 7.79167 13.8542 7.79167C12.0312 7.79167 10.4818 8.42969 9.20573 9.70573C7.92969 10.9818 7.29167 12.5312 7.29167 14.3542C7.29167 16.1771 7.92969 17.7266 9.20573 19.0026C10.4818 20.2786 12.0312 20.9167 13.8542 20.9167Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="TEXT MAGNIFIER">Text Magnifier</span>
                </div>
                <div class="ap-setting ap-gray-bg" id="btnReadingGuide" onclick="enableReadingGuide()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_884_995" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_884_995)">
                            <path d="M10.9375 32.5833C9.52782 32.5833 8.32469 32.085 7.32817 31.0885C6.33164 30.092 5.83337 28.8888 5.83337 27.4791V8.52079C5.83337 7.11107 6.33164 5.90795 7.32817 4.91142C8.32469 3.91489 9.52782 3.41663 10.9375 3.41663H29.1667V25.2916C28.5591 25.2916 28.0426 25.5043 27.6172 25.9296C27.1919 26.355 26.9792 26.8715 26.9792 27.4791C26.9792 28.0868 27.1919 28.6033 27.6172 29.0286C28.0426 29.454 28.5591 29.6666 29.1667 29.6666V32.5833H10.9375ZM8.75004 22.8489C9.09032 22.6788 9.44275 22.5572 9.80733 22.4843C10.1719 22.4114 10.5487 22.375 10.9375 22.375H11.6667V6.33329H10.9375C10.3299 6.33329 9.81341 6.54597 9.38806 6.97131C8.96271 7.39666 8.75004 7.91315 8.75004 8.52079V22.8489ZM14.5834 22.375H26.25V6.33329H14.5834V22.375ZM10.9375 29.6666H24.5365C24.3907 29.3263 24.2752 28.98 24.1901 28.6276C24.1051 28.2751 24.0625 27.8923 24.0625 27.4791C24.0625 27.0902 24.099 26.7135 24.1719 26.3489C24.2448 25.9843 24.3664 25.6319 24.5365 25.2916H10.9375C10.3056 25.2916 9.78303 25.5043 9.36983 25.9296C8.95664 26.355 8.75004 26.8715 8.75004 27.4791C8.75004 28.1111 8.95664 28.6336 9.36983 29.0468C9.78303 29.46 10.3056 29.6666 10.9375 29.6666Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="READING GUIDE">Reading Guide</span>
                </div>
            </div>

            <div class="ap-setting-half">
                <div class="ap-setting ap-gray-bg" id="btnReadingMask" onclick="enableReadingMask()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_884_1012" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_884_1012)">
                            <path d="M7.29163 20.9167H20.4166V10.7084H7.29163V20.9167ZM5.83329 29.6667C5.03121 29.6667 4.34458 29.3811 3.7734 28.8099C3.20222 28.2388 2.91663 27.5521 2.91663 26.75V9.25004C2.91663 8.44796 3.20222 7.76133 3.7734 7.19014C4.34458 6.61896 5.03121 6.33337 5.83329 6.33337H29.1666C29.9687 6.33337 30.6553 6.61896 31.2265 7.19014C31.7977 7.76133 32.0833 8.44796 32.0833 9.25004V26.75C32.0833 27.5521 31.7977 28.2388 31.2265 28.8099C30.6553 29.3811 29.9687 29.6667 29.1666 29.6667H5.83329ZM5.83329 26.75H29.1666V9.25004H5.83329V26.75Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="READING MASK">Reading Mask</span>
                </div>
                <div class="ap-setting ap-gray-bg" id="btnHighlightHeading" onclick="enableHighlightHeadings()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_912_6" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_912_6)">
                            <path d="M14.0001 15.0833L21.8751 22.9583L14.5834 30.25C14.0001 30.8333 13.3195 31.125 12.5417 31.125C11.7639 31.125 11.0834 30.8333 10.5001 30.25L10.4271 30.1771L10.3178 30.2865C10.0504 30.5538 9.74051 30.7604 9.38808 30.9063C9.03565 31.0521 8.66499 31.125 8.2761 31.125H3.93755C3.59728 31.125 3.36637 30.9792 3.24485 30.6875C3.12332 30.3958 3.18408 30.1285 3.42714 29.8854L6.7813 26.5313L6.70839 26.4583C6.12505 25.875 5.83339 25.1944 5.83339 24.4167C5.83339 23.6389 6.12505 22.9583 6.70839 22.375L14.0001 15.0833ZM16.0782 13.0052L23.3334 5.75C23.9167 5.16667 24.5973 4.875 25.3751 4.875C26.1528 4.875 26.8334 5.16667 27.4167 5.75L31.2084 9.54167C31.7917 10.125 32.0834 10.8056 32.0834 11.5833C32.0834 12.3611 31.7917 13.0417 31.2084 13.625L23.9532 20.8802L16.0782 13.0052Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="HIGHLIGHT HEADINGS">Highlight Headings</span>
                </div>
            </div>

            <div class="ap-setting-half">
                <div class="ap-setting ap-gray-bg" id="btnHighlightLink" onclick="enableHighlightLinks()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_912_240" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_912_240)">
                            <path d="M10.2083 25.2917C8.19093 25.2917 6.47131 24.5808 5.04944 23.1589C3.62756 21.737 2.91663 20.0174 2.91663 18C2.91663 15.9827 3.62756 14.2631 5.04944 12.8412C6.47131 11.4193 8.19093 10.7084 10.2083 10.7084H14.5833C14.9965 10.7084 15.3428 10.8481 15.6224 11.1276C15.9019 11.4072 16.0416 11.7535 16.0416 12.1667C16.0416 12.5799 15.9019 12.9263 15.6224 13.2058C15.3428 13.4853 14.9965 13.625 14.5833 13.625H10.2083C8.99301 13.625 7.96003 14.0504 7.10933 14.9011C6.25864 15.7518 5.83329 16.7848 5.83329 18C5.83329 19.2153 6.25864 20.2483 7.10933 21.099C7.96003 21.9497 8.99301 22.375 10.2083 22.375H14.5833C14.9965 22.375 15.3428 22.5148 15.6224 22.7943C15.9019 23.0738 16.0416 23.4202 16.0416 23.8334C16.0416 24.2466 15.9019 24.5929 15.6224 24.8724C15.3428 25.152 14.9965 25.2917 14.5833 25.2917H10.2083ZM13.125 19.4584C12.7118 19.4584 12.3654 19.3186 12.0859 19.0391C11.8064 18.7596 11.6666 18.4132 11.6666 18C11.6666 17.5868 11.8064 17.2405 12.0859 16.961C12.3654 16.6815 12.7118 16.5417 13.125 16.5417H21.875C22.2882 16.5417 22.6345 16.6815 22.914 16.961C23.1935 17.2405 23.3333 17.5868 23.3333 18C23.3333 18.4132 23.1935 18.7596 22.914 19.0391C22.6345 19.3186 22.2882 19.4584 21.875 19.4584H13.125ZM20.4166 25.2917C20.0034 25.2917 19.6571 25.152 19.3776 24.8724C19.098 24.5929 18.9583 24.2466 18.9583 23.8334C18.9583 23.4202 19.098 23.0738 19.3776 22.7943C19.6571 22.5148 20.0034 22.375 20.4166 22.375H24.7916C26.0069 22.375 27.0399 21.9497 27.8906 21.099C28.7413 20.2483 29.1666 19.2153 29.1666 18C29.1666 16.7848 28.7413 15.7518 27.8906 14.9011C27.0399 14.0504 26.0069 13.625 24.7916 13.625H20.4166C20.0034 13.625 19.6571 13.4853 19.3776 13.2058C19.098 12.9263 18.9583 12.5799 18.9583 12.1667C18.9583 11.7535 19.098 11.4072 19.3776 11.1276C19.6571 10.8481 20.0034 10.7084 20.4166 10.7084H24.7916C26.809 10.7084 28.5286 11.4193 29.9505 12.8412C31.3724 14.2631 32.0833 15.9827 32.0833 18C32.0833 20.0174 31.3724 21.737 29.9505 23.1589C28.5286 24.5808 26.809 25.2917 24.7916 25.2917H20.4166Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="HIGHLIGHT LINKS">Highlight Links</span>
                </div>
                <div class="ap-setting ap-gray-bg" id="btnStopAnimation" onclick="stopAnimation()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_884_1029" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_884_1029)">
                            <path d="M13.125 22.375H16.0416V13.625H13.125V22.375ZM18.9583 22.375H21.875V13.625H18.9583V22.375ZM17.5 32.5833C15.4826 32.5833 13.5868 32.2005 11.8125 31.4349C10.0382 30.6692 8.49475 29.6302 7.18225 28.3177C5.86975 27.0052 4.83069 25.4618 4.06506 23.6875C3.29944 21.9132 2.91663 20.0173 2.91663 18C2.91663 16.9548 3.026 15.9279 3.24475 14.9192C3.4635 13.9105 3.77947 12.9323 4.19267 11.9843L6.45308 14.2448C6.25864 14.8767 6.10673 15.5026 5.99735 16.1224C5.88798 16.7421 5.83329 17.368 5.83329 18C5.83329 21.2569 6.9635 24.0156 9.22392 26.276C11.4843 28.5364 14.243 29.6666 17.5 29.6666C20.7569 29.6666 23.5156 28.5364 25.776 26.276C28.0364 24.0156 29.1666 21.2569 29.1666 18C29.1666 14.743 28.0364 11.9843 25.776 9.72392C23.5156 7.4635 20.7569 6.33329 17.5 6.33329C16.8437 6.33329 16.2057 6.38798 15.5859 6.49735C14.9661 6.60673 14.3524 6.75864 13.7448 6.95308L11.5208 4.72913C12.493 4.29163 13.4652 3.9635 14.4375 3.74475C15.4097 3.526 16.4305 3.41663 17.5 3.41663C19.5173 3.41663 21.4132 3.79944 23.1875 4.56506C24.9618 5.33069 26.5052 6.36975 27.8177 7.68225C29.1302 8.99475 30.1692 10.5382 30.9349 12.3125C31.7005 14.0868 32.0833 15.9826 32.0833 18C32.0833 20.0173 31.7005 21.9132 30.9349 23.6875C30.1692 25.4618 29.1302 27.0052 27.8177 28.3177C26.5052 29.6302 24.9618 30.6692 23.1875 31.4349C21.4132 32.2005 19.5173 32.5833 17.5 32.5833ZM8.02079 10.7083C7.41315 10.7083 6.89666 10.4956 6.47131 10.0703C6.04597 9.64492 5.83329 9.12843 5.83329 8.52079C5.83329 7.91315 6.04597 7.39666 6.47131 6.97131C6.89666 6.54597 7.41315 6.33329 8.02079 6.33329C8.62843 6.33329 9.14492 6.54597 9.57027 6.97131C9.99562 7.39666 10.2083 7.91315 10.2083 8.52079C10.2083 9.12843 9.99562 9.64492 9.57027 10.0703C9.14492 10.4956 8.62843 10.7083 8.02079 10.7083Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="STOP ANIMATION">Stop Animation</span>
                </div>
            </div>

            <div class="ap-setting-half">
                <div class="ap-setting ap-gray-bg" id="btnMuteSound" onclick="muteSounds()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_884_1046" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_884_1046)">
                            <path d="M28.875 33.4584L24.4635 29.0469C23.8559 29.4358 23.2118 29.77 22.5312 30.0495C21.8507 30.329 21.1458 30.5539 20.4166 30.724V27.7344C20.7569 27.6129 21.0911 27.4914 21.4192 27.3698C21.7474 27.2483 22.0573 27.1025 22.3489 26.9323L17.5 22.0834V29.6667L10.2083 22.375H4.37496V13.625H9.04163L2.04163 6.62504L4.08329 4.58337L30.9166 31.4167L28.875 33.4584ZM28.5833 25L26.4687 22.8855C26.8819 22.132 27.1918 21.3421 27.3984 20.5157C27.605 19.6893 27.7083 18.8386 27.7083 17.9636C27.7083 15.6789 27.0399 13.6372 25.7031 11.8386C24.3663 10.04 22.6041 8.82469 20.4166 8.19275V5.20317C23.4305 5.88372 25.8854 7.4089 27.7812 9.77869C29.677 12.1485 30.625 14.8768 30.625 17.9636C30.625 19.2518 30.4487 20.4914 30.0963 21.6823C29.7439 22.8733 29.2395 23.9792 28.5833 25ZM23.6979 20.1146L20.4166 16.8334V12.0938C21.559 12.6285 22.4522 13.4306 23.0963 14.5C23.7404 15.5695 24.0625 16.7362 24.0625 18C24.0625 18.3646 24.0321 18.7231 23.9713 19.0756C23.9106 19.428 23.8194 19.7743 23.6979 20.1146ZM17.5 13.9167L13.7083 10.125L17.5 6.33337V13.9167ZM14.5833 22.5938V19.1667L11.9583 16.5417H7.29163V19.4584H11.4479L14.5833 22.5938Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="MUTE SOUNDS">Mute Sounds</span>
                </div>
                <div class="ap-setting ap-gray-bg" id="btnHideImage" onclick="hideImages()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_884_1063" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_884_1063)">
                            <path d="M30.625 26.9688L27.7083 24.0521V7.79171H11.4479L8.53121 4.87504H27.7083C28.5104 4.87504 29.197 5.16063 29.7682 5.73181C30.3394 6.30299 30.625 6.98962 30.625 7.79171V26.9688ZM28.875 33.4584L26.5416 31.125H7.29163C6.48954 31.125 5.80291 30.8395 5.23173 30.2683C4.66055 29.6971 4.37496 29.0105 4.37496 28.2084V8.95837L2.04163 6.62504L4.08329 4.58337L30.9166 31.4167L28.875 33.4584ZM8.74996 25.2917L13.125 19.4584L16.4062 23.8334L17.6093 22.2292L7.29163 11.9115V28.2084H23.5885L20.6718 25.2917H8.74996Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="HIDE IMAGES">Hide Images</span>
                </div>
            </div>

            <div class="ap-setting-half">
                <div class="ap-setting ap-gray-bg" id="btnImageAlt" onclick="generateAltTag()" style="position: relative;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_912_352" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_912_352)">
                            <path d="M5.83329 29.6667C5.03121 29.6667 4.34458 29.3811 3.7734 28.8099C3.20222 28.2388 2.91663 27.5521 2.91663 26.75V9.25004C2.91663 8.44796 3.20222 7.76133 3.7734 7.19014C4.34458 6.61896 5.03121 6.33337 5.83329 6.33337H29.1666C29.9687 6.33337 30.6553 6.61896 31.2265 7.19014C31.7977 7.76133 32.0833 8.44796 32.0833 9.25004V26.75C32.0833 27.5521 31.7977 28.2388 31.2265 28.8099C30.6553 29.3811 29.9687 29.6667 29.1666 29.6667H5.83329ZM16.4062 22.375L13.7083 18.7657C13.5625 18.5712 13.368 18.474 13.125 18.474C12.8819 18.474 12.6875 18.5712 12.5416 18.7657L9.62496 22.6667C9.43051 22.9098 9.40621 23.165 9.55204 23.4323C9.69788 23.6997 9.91663 23.8334 10.2083 23.8334H24.7916C25.0833 23.8334 25.302 23.6997 25.4479 23.4323C25.5937 23.165 25.5694 22.9098 25.375 22.6667L21.3645 17.3073C21.2187 17.1129 21.0243 17.0157 20.7812 17.0157C20.5382 17.0157 20.3437 17.1129 20.1979 17.3073L16.4062 22.375Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="DESCRIBE IMAGES">Describe Images</span>
                </div>
                <div class="ap-setting ap-gray-bg" id="btnTextSpeech" onclick="textToSpeech()" style="position: relative;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 35 36" fill="none">
                        <mask id="mask0_884_1074" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="35" height="36">
                            <rect y="0.5" width="35" height="35" fill="#D9D9D9" />
                        </mask>
                        <g mask="url(#mask0_884_1074)">
                            <path d="M5.83329 32.5833C5.03121 32.5833 4.34458 32.2977 3.7734 31.7266C3.20222 31.1554 2.91663 30.4688 2.91663 29.6667V6.33333C2.91663 5.53125 3.20222 4.84462 3.7734 4.27344C4.34458 3.70226 5.03121 3.41667 5.83329 3.41667H18.9583L16.0416 6.33333H5.83329V29.6667H21.875V25.2917H24.7916V29.6667C24.7916 30.4688 24.506 31.1554 23.9349 31.7266C23.3637 32.2977 22.677 32.5833 21.875 32.5833H5.83329ZM8.74996 26.75V23.8333H18.9583V26.75H8.74996ZM8.74996 22.375V19.4583H16.0416V22.375H8.74996ZM21.875 22.375L16.0416 16.5417H11.6666V9.25H16.0416L21.875 3.41667V22.375ZM24.7916 17.9271V7.86458C25.6666 8.375 26.3715 9.06771 26.9062 9.94271C27.4409 10.8177 27.7083 11.8021 27.7083 12.8958C27.7083 13.9896 27.4409 14.974 26.9062 15.849C26.3715 16.724 25.6666 17.4167 24.7916 17.9271ZM24.7916 24.1979V21.1354C26.493 20.5278 27.8906 19.4766 28.9843 17.9818C30.0781 16.487 30.625 14.7917 30.625 12.8958C30.625 11 30.0781 9.30469 28.9843 7.8099C27.8906 6.3151 26.493 5.26389 24.7916 4.65625V1.59375C27.3194 2.25 29.4097 3.61719 31.0625 5.69531C32.7152 7.77344 33.5416 10.1736 33.5416 12.8958C33.5416 15.6181 32.7152 18.0182 31.0625 20.0964C29.4097 22.1745 27.3194 23.5417 24.7916 24.1979Z" fill="black" />
                        </g>
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="TEXT TO SPEECH">Text to Speech</span>
                </div>
            </div>

            <div class="ap-setting-half">
                <div class="ap-setting ap-gray-bg" id="btnHideVideo" onclick="hideVideo()" style="position: relative;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="36" viewBox="0 0 25 25" fill="none">
                        <path d="M5.58578644,7 L3,7 L3,17 L15,17 L15,16.4142136 L5.58578644,7 Z M16.6766123,18.0908259 C16.3197659,18.6381832 15.7021364,19 15,19 L3,19 C1.8954305,19 1,18.1045695 1,17 L1,7 C1,5.8954305 1.8954305,5 3,5 L3.58578644,5 L0.292893219,1.70710678 L1.70710678,0.292893219 L23.7071068,22.2928932 L22.2928932,23.7071068 L16.6766123,18.0908259 Z M17,8.38196601 L23,5.38196601 L23,18.370101 L21,16.370101 L21,8.61803399 L17,10.618034 L17,13.0007865 L15,11.0007865 L15,7 L10.9992135,7 L8.99921354,5 L15,5 C16.1045695,5 17,5.8954305 17,7 L17,8.38196601 Z" fill="black" />
                    </svg>
                    <span class="ap-font-18 ap-fw-400" data-ap-translate="HIDE VIDEO">Hide Video</span>
                </div>
            </div>
        </div>
    </div>
</div>