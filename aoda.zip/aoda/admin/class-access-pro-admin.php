<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://qodemedia.com
 * @since      1.0.0
 *
 * @package    Access_Pro
 * @subpackage Access_Pro/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Access_Pro
 * @subpackage Access_Pro/admin
 * @author     qodemedia <avi@qodemedia.com>
 */
class Access_Pro_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Access_Pro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Access_Pro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/access-pro-admin.css', array(), $this->version, 'all' );
		wp_enqueue_style( "menu-style", plugin_dir_url( __FILE__ ) . 'css/style.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Access_Pro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Access_Pro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		$current_screen = get_current_screen();

		if ($current_screen->id === 'toplevel_page_access-pro' || $current_screen->id === 'access-pro_page_access-pro') {
			$all_configs = $this->get_all_configs_data();
			wp_enqueue_script( 'access-pro-admin', plugin_dir_url( __FILE__ ) . 'js/access-pro-admin.js', array( 'jquery' ), $this->version, false );
			wp_localize_script('access-pro-admin', 'apAllConfigsLocalizer', $all_configs);
			wp_localize_script('access-pro-admin', 'apAdminLocalizer', [
				'apiUrl' => home_url('/wp-json'),
			]);
			wp_enqueue_script('menu-script', plugin_dir_url(__FILE__) . 'js/admin-menu-widget.js', [], $this->version, false);
			wp_localize_script('menu-script', 'apAdminLocalizer', [
				'apiUrl' => home_url('/wp-json'),
			]);
		}
	}

	/**
	 * [add_admin_menu description]
	 */
	public function add_admin_menu()
	{
		global $submenu;

		add_menu_page(
			__('Access Pro', 'access-pro'),
			__('Access Pro', 'access-pro'),
			'manage_options',
			'access-pro',
			array($this, 'display_plugin_setup_page'),
			'dashicons-universal-access-alt',
		);

		if (current_user_can('manage_options')) {
			add_submenu_page(
				'access-pro',
				__('Access Pro - Dashboard', 'access-pro-dashboard'),
				__('Dashboard', 'access-pro-dashboard'),
				'manage_options',
				'access-pro',
				array($this, 'display_plugin_setup_page')
			);

			// add_submenu_page(
			// 	'quantum-scout-idx',
			// 	__('Quantum Scout IDX - Contact Leads', 'quantum-scout-idx-contact-leads'),
			// 	__('Contact Leads', 'quantum-scout-idx-contact-leads'),
			// 	'manage_options',
			// 	'admin.php?page=quantum-scout-idx#/contact-leads'
			// );

			// add_submenu_page(
			// 	'quantum-scout-idx',
			// 	__('Quantum Scout IDX - Short Codes', 'quantum-scout-idx-short-codes'),
			// 	__('Short Codes', 'quantum-scout-idx-short-codes'),
			// 	'manage_options',
			// 	'admin.php?page=quantum-scout-idx#/short-codes'
			// );

			// add_submenu_page(
			// 	'quantum-scout-idx',
			// 	__('Quantum Scout IDX - Activity Tracking', 'quantum-scout-idx-activity-tracking'),
			// 	__('Activity Tracking', 'quantum-scout-idx-activity-tracking'),
			// 	'manage_options',
			// 	'admin.php?page=quantum-scout-idx#/activity-tracking'
			// );

			// add_submenu_page(
			// 	'quantum-scout-idx',
			// 	__('Quantum Scout IDX - Custom Listing', 'quantum-scout-idx-custom-listing'),
			// 	__('Custom Listing', 'quantum-scout-idx-custom-listing'),
			// 	'manage_options',
			// 	'admin.php?page=quantum-scout-idx#/custom-listing'
			// );

			// add_submenu_page(
			// 	'quantum-scout-idx',
			// 	__('Quantum Scout IDX - FAQ', 'quantum-scout-idx-faq'),
			// 	__('FAQ', 'quantum-scout-idx-faq'),
			// 	'manage_options',
			// 	'admin.php?page=quantum-scout-idx#/faq'
			// );
		}
	}

	/**
	 * [display_plugin_setup_page description]
	 * @return [type] [description]
	 */
	// public function display_plugin_setup_page()
	// {
	// 	echo '<div class="wrap"><div id="qsidx-admin-app" class="qsidx-admin"></div></div>';
	// }

	/**
	 * [display_plugin_setup_page description]
	 * @return [type] [description]
	 */
	public function display_plugin_setup_page()
	{
		include_once('partials/access-pro-admin-display.php');
	}

	/**
	 * Get All Configs Data
	 *
	 * @return array
	 */
	function get_all_configs_data()
	{
		global $wpdb;
		$prefix 	 	 = $wpdb->prefix . "access_pro_";

		$sql = "SELECT `key`,`value` FROM `{$prefix}configs`";
		$all_configs_result = $wpdb->get_results($sql);

		$all_configs = array();
		foreach ($all_configs_result as $config) {
			$all_configs[$config->key] = $config->value;
		}
		return $all_configs;
	}

}
