(function( $ ) {
	'use strict';

	const languages = [
		{ code: "aa", name: "Afar" },
		{ code: "ab", name: "Abkhazian" },
		{ code: "ae", name: "Avestan" },
		{ code: "af", name: "Afrikaans" },
		{ code: "ak", name: "Akan" },
		{ code: "am", name: "Amharic" },
		{ code: "an", name: "Aragonese" },
		{ code: "ar", name: "Arabic" },
		{ code: "as", name: "Assamese" },
		{ code: "av", name: "Avaric" },
		{ code: "ay", name: "Aymara" },
		{ code: "az", name: "Azerbaijani" },
		{ code: "ba", name: "Bashkir" },
		{ code: "be", name: "Belarusian" },
		{ code: "bg", name: "Bulgarian" },
		{ code: "bh", name: "Bihari languages" },
		{ code: "bi", name: "Bislama" },
		{ code: "bm", name: "Bambara" },
		{ code: "bn", name: "Bengali" },
		{ code: "bo", name: "Tibetan" },
		{ code: "br", name: "Breton" },
		{ code: "bs", name: "Bosnian" },
		{ code: "ca", name: "Catalan, Valencian" },
		{ code: "ce", name: "Chechen" },
		{ code: "ch", name: "Chamorro" },
		{ code: "co", name: "Corsican" },
		{ code: "cr", name: "Cree" },
		{ code: "cs", name: "Czech" },
		{ code: "cu", name: "Church Slavic, Slavonic, Church Slavonic" },
		{ code: "cv", name: "Chuvash" },
		{ code: "cy", name: "Welsh" },
		{ code: "da", name: "Danish" },
		{ code: "de", name: "German" },
		{ code: "dv", name: "Divehi, Dhivehi, Maldivian" },
		{ code: "dz", name: "Dzongkha" },
		{ code: "ee", name: "Ewe" },
		{ code: "el", name: "Greek, Modern (1453-)" },
		{ code: "en", name: "English" },
		{ code: "eo", name: "Esperanto" },
		{ code: "es", name: "Spanish, Castilian" },
		{ code: "et", name: "Estonian" },
		{ code: "eu", name: "Basque" },
		{ code: "fa", name: "Persian" },
		{ code: "ff", name: "Fulah" },
		{ code: "fi", name: "Finnish" },
		{ code: "fj", name: "Fijian" },
		{ code: "fo", name: "Faroese" },
		{ code: "fr", name: "French" },
		{ code: "fy", name: "Western Frisian" },
		{ code: "ga", name: "Irish" },
		{ code: "gd", name: "Gaelic, Scomttish Gaelic" },
		{ code: "gl", name: "Galician" },
		{ code: "gn", name: "Guarani" },
		{ code: "gu", name: "Gujarati" },
		{ code: "gv", name: "Manx" },
		{ code: "ha", name: "Hausa" },
		{ code: "he", name: "Hebrew" },
		{ code: "hi", name: "Hindi" },
		{ code: "ho", name: "Hiri Motu" },
		{ code: "hr", name: "Croatian" },
		{ code: "ht", name: "Haitian, Haitian Creole" },
		{ code: "hu", name: "Hungarian" },
		{ code: "hy", name: "Armenian" },
		{ code: "hz", name: "Herero" },
		{ code: "ia", name: "Interlingua (International Auxiliary Language Association)" },
		{ code: "id", name: "Indonesian" },
		{ code: "ie", name: "Interlingue, Occidental" },
		{ code: "ig", name: "Igbo" },
		{ code: "ii", name: "Sichuan Yi, Nuosu" },
		{ code: "ik", name: "Inupiaq" },
		{ code: "io", name: "Ido" },
		{ code: "is", name: "Icelandic" },
		{ code: "it", name: "Italian" },
		{ code: "iu", name: "Inuktitut" },
		{ code: "ja", name: "Japanese" },
		{ code: "jv", name: "Javanese" },
		{ code: "ka", name: "Georgian" },
		{ code: "kg", name: "Kongo" },
		{ code: "ki", name: "Kikuyu, Gikuyu" },
		{ code: "kj", name: "Kuanyama, Kwanyama" },
		{ code: "kk", name: "Kazakh" },
		{ code: "kl", name: "Kalaallisut, Greenlandic" },
		{ code: "km", name: "Central Khmer" },
		{ code: "kn", name: "Kannada" },
		{ code: "ko", name: "Korean" },
		{ code: "kr", name: "Kanuri" },
		{ code: "ks", name: "Kashmiri" },
		{ code: "ku", name: "Kurdish" },
		{ code: "kv", name: "Komi" },
		{ code: "kw", name: "Cornish" },
		{ code: "ky", name: "Kirghiz, Kyrgyz" },
		{ code: "la", name: "Latin" },
		{ code: "lb", name: "Luxembourgish, Letzeburgesch" },
		{ code: "lg", name: "Ganda" },
		{ code: "li", name: "Limburgan, Limburger, Limburgish" },
		{ code: "ln", name: "Lingala" },
		{ code: "lo", name: "Lao" },
		{ code: "lt", name: "Lithuanian" },
		{ code: "lu", name: "Luba-Katanga" },
		{ code: "lv", name: "Latvian" },
		{ code: "mg", name: "Malagasy" },
		{ code: "mh", name: "Marshallese" },
		{ code: "mi", name: "Maori" },
		{ code: "mk", name: "Macedonian" },
		{ code: "ml", name: "Malayalam" },
		{ code: "mn", name: "Mongolian" },
		{ code: "mr", name: "Marathi" },
		{ code: "ms", name: "Malay" },
		{ code: "mt", name: "Maltese" },
		{ code: "my", name: "Burmese" },
		{ code: "na", name: "Nauru" },
		{ code: "nb", name: "Bokmål, Norwegian, Norwegian Bokmål" },
		{ code: "nd", name: "Ndebele, North, North Ndebele" },
		{ code: "ne", name: "Nepali" },
		{ code: "ng", name: "Ndonga" },
		{ code: "nl", name: "Dutch; Flemish" },
		{ code: "nn", name: "Norwegian Nynorsk, Nynorsk, Norwegian" },
		{ code: "no", name: "Norwegian" },
		{ code: "nr", name: "Ndebele, South, South Ndebele" },
		{ code: "nv", name: "Navajo, Navaho" },
		{ code: "ny", name: "Chichewa, Chewa, Nyanja" },
		{ code: "oc", name: "Occitan (post 1500)" },
		{ code: "oj", name: "Ojibwa" },
		{ code: "om", name: "Oromo" },
		{ code: "or", name: "Oriya" },
		{ code: "os", name: "Ossetian, Ossetic" },
		{ code: "pa", name: "Panjabi, Punjabi" },
		{ code: "pi", name: "Pali" },
		{ code: "pl", name: "Polish" },
		{ code: "ps", name: "Pushto, Pashto" },
		{ code: "pt", name: "Portuguese" },
		{ code: "qu", name: "Quechua" },
		{ code: "rm", name: "Romansh" },
		{ code: "rn", name: "Rundi" },
		{ code: "ro", name: "Romanian, Moldavian, Moldovan" },
		{ code: "ru", name: "Russian" },
		{ code: "rw", name: "Kinyarwanda" },
		{ code: "sa", name: "Sanskrit" },
		{ code: "sc", name: "Sardinian" },
		{ code: "sd", name: "Sindhi" },
		{ code: "se", name: "Northern Sami" },
		{ code: "sg", name: "Sango" },
		{ code: "si", name: "Sinhala, Sinhalese" },
		{ code: "sk", name: "Slovak" },
		{ code: "sl", name: "Slovenian" },
		{ code: "sm", name: "Samoan" },
		{ code: "sn", name: "Shona" },
		{ code: "so", name: "Somali" },
		{ code: "sq", name: "Albanian" },
		{ code: "sr", name: "Serbian" },
		{ code: "ss", name: "Swati" },
		{ code: "st", name: "Sotho, Southern" },
		{ code: "su", name: "Sundanese" },
		{ code: "sv", name: "Swedish" },
		{ code: "sw", name: "Swahili" },
		{ code: "ta", name: "Tamil" },
		{ code: "te", name: "Telugu" },
		{ code: "tg", name: "Tajik" },
		{ code: "th", name: "Thai" },
		{ code: "ti", name: "Tigrinya" },
		{ code: "tk", name: "Turkmen" },
		{ code: "tl", name: "Tagalog" },
		{ code: "tn", name: "Tswana" },
		{ code: "to", name: "Tonga (Tonga Islands)" },
		{ code: "tr", name: "Turkish" },
		{ code: "ts", name: "Tsonga" },
		{ code: "tt", name: "Tatar" },
		{ code: "tw", name: "Twi" },
		{ code: "ty", name: "Tahitian" },
		{ code: "ug", name: "Uighur, Uyghur" },
		{ code: "uk", name: "Ukrainian" },
		{ code: "ur", name: "Urdu" },
		{ code: "uz", name: "Uzbek" },
		{ code: "ve", name: "Venda" },
		{ code: "vi", name: "Vietnamese" },
		{ code: "vo", name: "Volapük" },
		{ code: "wa", name: "Walloon" },
		{ code: "wo", name: "Wolof" },
		{ code: "xh", name: "Xhosa" },
		{ code: "yi", name: "Yiddish" },
		{ code: "yo", name: "Yoruba" },
		{ code: "za", name: "Zhuang, Chuang" },
		{ code: "zh", name: "Chinese" },
		{ code: "zu", name: "Zulu" },
	];
	const widgetLanguages = [
		{ label: "Čeština (cs)", value: "cs" },
		{ label: "Deutsch (de)", value: "de" },
		{ label: "English (en)", value: "en" },
		{ label: "Español (es)", value: "es" },
		{ label: "Français (fr)", value: "fr" },
		{ label: "Italiano (it)", value: "it" },
		{ label: "Magyar (hu)", value: "hu" },
		{ label: "Nederlands (nl)", value: "nl" },
		{ label: "Polski (pl)", value: "pl" },
		{ label: "Português (pt)", value: "pt" },
		{ label: "Pусский (ru)", value: "ru" },
		{ label: "Slovenčina (sk)", value: "sk" },
		{ label: "Slovenščina (sl)", value: "sl" },
		{ label: "Türkçe (tr)", value: "tr" },
		{ label: "Ελληνικά (el)", value: "el" },
		{ label: "українська (uk)", value: "uk" },
		{ label: "עברית (he)", value: "he" },
		{ label: "العربية (ar)", value: "ar" },
		{ label: "日本語 (ja)", value: "ja" },
		{ label: "简体中文 (zh)", value: "zh" },
		{ label: "繁體中文 (tw)", value: "tw" },
  ];
	const cssPositions = {
		"top-left": { left: "160px", top: "20px" },
		"top-right": { right: "20px", top: "20px" },
		"middle-left": { left: "160px", top: "50%" },
		"middle-right": { right: "20px", top: "50%" },
		"bottom-left": { left: "160px", bottom: "20px" },
		"bottom-right": { right: "20px", bottom: "20px" },
	};

	let selectedLanguageLists = [];
	let translationLanguageLists = [];
	let isDragging = false;
	let offsetX;
	let offsetY;

	function saveSettings(e = null) {
		e && e.preventDefault();

		const formData = new FormData(document.getElementById("settingsForm"));
		const formDataObject = {};
		formData.forEach((value, key) => {
			formDataObject[key] = value;
		});

		if (!formDataObject.enable_features) {
			formDataObject.enable_features = '0';
		} else {
			formDataObject.enable_features = 'on' ? '1' : '0';
		}

		if (!formDataObject.enable_language) {
			formDataObject.enable_language = '0';
		} else {
			formDataObject.enable_language = 'on' ? '1' : '0';
		}

		formDataObject.language_list = JSON.stringify(selectedLanguageLists);
		if (translationLanguageLists.length < 1) {
			translationLanguageLists = ["all"]
		} else if(translationLanguageLists[0] == "all") {
			translationLanguageLists.splice(1, translationLanguageLists.length);
		}
				
		formDataObject.translation_language_list = JSON.stringify(translationLanguageLists);

		let url = apAdminLocalizer.apiUrl + "/ap/v1/settings/save-config-data";

		fetch(url, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify(formDataObject),
		})
		.then((response) => response.json())
		.then((data) => {
			if (!e) {
				window.location.reload()
			}
			if (data.status === 'success') {
				showAlert('Settings saved successfully!', 'success');
			} else {
				showAlert('Error saving settings. Please try again.', 'error');
			}
		})
		.catch((error) => {
			showAlert('An unexpected error occurred. Please try again later.', 'error');
		});
  	}

	function resetSettings(e) {
		e.preventDefault();
		$('input[name="enable_features"]').prop("checked", true);
		$(".ap-disable-icon-overlay").css("display", "none");
		$("#ap-enable-status").text("enabled");
		$("#asw-icon").css("display", "block");
		$("#aswMenu").css("display", "none");

		//icon size settings
		document.getElementById("size1x").checked = true;

		// icon position settings
		document.querySelectorAll(".ap-icon-position").forEach(el => {
			el.style.background = "#FFF";
			el.style.color = "#000";
			el
			.querySelector("svg")
			.querySelector("path")
			.setAttribute("fill", "#949494");
		});
		$('input[name="position"]').each(function () {
			if (this.value === "bottom-left") {
				this.checked = true;
				const wrapper = this.closest(".ap-icon-position");
				wrapper.style.background = "#1E1E1E";
				wrapper.style.color = "#FFF";
				wrapper
					.querySelector("svg")
					.querySelector("path")
					.setAttribute("fill", "#fff");
			} else {
				this.checked = false;
			}
		});
		const positionStyle = cssPositions["bottom-left"];

		if (positionStyle) {
			$("#asw-icon").css("left", '');
			$("#asw-icon").css("right", '');
			$("#asw-icon").css("top", '');
			$("#asw-icon").css("bottom", '');
			$("#aswMenu").css("left", '');
			$("#aswMenu").css("right", '');
			$("#aswMenu").css("top", '');
			$("#aswMenu").css("bottom", '');
			$("#aswMenu").css("transform", '');
			for (const [property, value] of Object.entries(positionStyle)) {
				$("#asw-icon").css(property,value);
				$("#aswMenu").css(property, value);
			}
			$("#aswMenu").css("z-index", Number.MAX_SAFE_INTEGER);
		}

		// menu icon settings
		$('input[name="icon_stroke_color"]').val("#419D4A");
		$('input[name="icon_fill_color"]').val("#419D4A");
		$("#apMenuIconStroke").attr("stroke", "#419D4A");
		$("#apPreviewIconStroke").attr("stroke", "#419D4A");
		$("#apMenuIconFill").attr("fill", "#419D4A");
		$("#apPreviewIconFill").attr("fill", "#419D4A");

		// menu settings
		$('input[name="menu_content_color"]').val("#000000");
		$('input[name="menu_header_bg_color"]').val("#000000");
		$('input[name="menu_header_font_color"]').val("#FFFFFF");

		// language settings
		$('input[name="enable_language"]').prop("checked", false);
		$(".ap-disable-language-overlay").css("display", "block");
		$("#asw-website-lang").text("");
		$("#apSelectedLanguage").text("No language selected.");
		selectedLanguageLists = [];
		
		saveSettings();
	}

	function openResetDialog(e) {
		e.preventDefault();
		const dialog = document.querySelector(".ap-reset-setting-dialog-wrapper");
		dialog.style.display = "block";
	}
	
	function closeResetDialog(e) {
		e.preventDefault();
		const dialog = document.querySelector(".ap-reset-setting-dialog-wrapper");
		dialog.style.display = "none";
	}

	function showAlert(message, type) {
		const alertElement = document.createElement("div");
		alertElement.className = `ap-alert ap-alert-${type}`;
		alertElement.textContent = message;
		alertElement.style.zIndex = Number.MAX_SAFE_INTEGER;
		document.querySelector(".ap-admin-wrapper").insertBefore(alertElement, document.querySelector(".ap-admin-wrapper").firstChild);

		setTimeout(() => {
			alertElement.remove();
		}, 3000);
	}

	function toggleMenu() {
		const menuWidget = document.getElementById("aswMenu");
		menuWidget.style.display = menuWidget.style.display === "none" ? "block" : "none"
	}

	function toggleLayoutDisplay() {
		const enableFeatures = document.getElementById('apBtnEnableFeature').checked;
		const previewIcon = document.getElementById("asw-icon");
		const menuWidget = document.getElementById("aswMenu");
		if (enableFeatures) {
			document.querySelector(".ap-disable-icon-overlay").style.display = "none";
			document.getElementById("ap-enable-status").innerText = "enabled";
			previewIcon.style.display = "block";
			menuWidget.style.display = "block";
		} else {
			document.querySelector(".ap-disable-icon-overlay").style.display = "block";
			document.getElementById("ap-enable-status").innerText = "disabled";
			previewIcon.style.display = "none";
			menuWidget.style.display = "none";
		}
	}

	function toggleLanguageDisplay() {
		const enableLanguage = document.getElementById('apBtnEnableLanguage').checked;
		if (enableLanguage) {
			document.querySelector(".ap-disable-language-overlay").style.display = "none";
			document.getElementById("asw-website-lang").innerText = `Languages: ${selectedLanguageLists.join(", ")}`;
			document.getElementById("asw-website-lang").style.display = "block";
		} else {
			document.querySelector(".ap-disable-language-overlay").style.display = "block";
			document.getElementById("asw-website-lang").innerText = "";
			document.getElementById("asw-website-lang").style.display = "none";
		}
	}

	function changeIconSize(e) {
		const icon = document.getElementById("apMenuIcon");
		const previewIcon = document.getElementById("asw-icon");
		if (e.target.value === "1x") {
			icon.classList.remove("ap-x2", "ap-x15")
			previewIcon.style.width = "60px";
			previewIcon.style.height = "60px";
		} else if (e.target.value === "1.5x") {
			icon.classList.remove("ap-x2")
			icon.classList.add("ap-x15")
			previewIcon.style.width = "75px";
			previewIcon.style.height = "75px";
		} else {
			icon.classList.remove("ap-x15")
			icon.classList.add("ap-x2")
			previewIcon.style.width = "90px";
			previewIcon.style.height = "90px";
		}
	}

	function toggleIconPosition(e) {
		const wrapper = e.target.closest(".ap-icon-position");
		const previewIcon = document.getElementById("asw-icon");
		const widget = document.getElementById("aswMenu");
		const position = e.target.value;
		document.querySelectorAll(".ap-icon-position").forEach(el => {
			el.style.background = "#FFF";
			el.style.color = "#000";
			el
			.querySelector("svg")
			.querySelector("path")
			.setAttribute("fill", "#949494");
		});

		wrapper.style.background = "#1E1E1E";
		wrapper.style.color = "#FFF";
		wrapper
			.querySelector("svg")
			.querySelector("path")
			.setAttribute("fill", "#fff");
		
		const positionStyle = cssPositions[position];

		if (positionStyle) {
			previewIcon.style.left = '';
			previewIcon.style.right = '';
			previewIcon.style.top = '';
			previewIcon.style.bottom = '';
			widget.style.left = '';
			widget.style.right = '';
			widget.style.top = '';
			widget.style.bottom = '';
			widget.style.transform = '';
			for (const [property, value] of Object.entries(positionStyle)) {
				previewIcon.style[property] = value;
				widget.style[property] = value;
			}
			widget.style.zIndex = Number.MAX_SAFE_INTEGER;
			if (position == "middle-right" || position == "middle-left") {
				widget.style.transform = "translateY(-50%)";
			}
			if (window.matchMedia("(max-width: 960px)").matches) {
				if (position == "top-left" || position == "middle-left" || position == "bottom-left") {
					previewIcon.style.left = "20px";
					widget.style.left = "20px";
				}
			}
		}
	}

	function changeColor(e, iconPos) {
		const color = e.target.value;
		if (iconPos === 'stroke') {
			$("#apMenuIconStroke").attr("stroke", color);
			$("#apPreviewIconStroke").attr("stroke", color);
		} else {
			$("#apMenuIconFill").attr("fill", color);
			$("#apPreviewIconFill").attr("fill", color);
		}
	}
	
	function changeMenuFontColor(e) {
		const color = e.target.value;
		document
		.querySelectorAll(
			`[data-ap-translate]:not([data-ap-translate="MENU TITLE"]):not([data-ap-translate="OFF"]):not([data-ap-translate="ON"]),#ap-selected-language,[data-lang],.ap-range-value`
		)
		.forEach((el) => {
			el.style.color = color;
		});
		document.querySelectorAll(".asw-menu svg,.asw-widget svg").forEach((el) => {
			el.querySelector("path").setAttribute("fill", color);
		});
		document.querySelectorAll(".ap-setting-button").forEach((el) => {
			el.style.border = `2px solid ${color}`;
		});
		document.querySelectorAll(".ap-setting").forEach((el) => {
			el.addEventListener("mouseover", () => {
				el.style.border = `3px solid ${color}`;
			});
		});
		changeRangeThumb(color);
	}
	
	function changeMenuHeaderBgColor(e) {
		const color = e.target.value;
		document.querySelectorAll(".asw-menu-header").forEach(el => {
			el.style.background = color
		});
		document.querySelectorAll(".ap-border-bottom").forEach((el) => {
			el.style.borderBottom = `1px solid ${color}`;
		});
	}
	
	function changeMenuHeaderColor(e) {
		const color = e.target.value;
		document.querySelectorAll(".asw-menu-header").forEach(el => {
			el.style.color = color;
		});
	}

	function updateLanguagesList(event) {
		const languageCode = event.target.value;
		const selectedLanguage = document.getElementById("apSelectedLanguage");
		
		const languageIndex = selectedLanguageLists.findIndex((language) => language === languageCode);

		if (languageIndex !== -1) {
			selectedLanguageLists.splice(languageIndex, 1);
		} else {
			selectedLanguageLists.push(languageCode);
		}

		if (selectedLanguageLists.length == 0) {
			selectedLanguage.innerText = "No language selected.";
			document.getElementById("asw-website-lang").innerText = "";
		} else {
			selectedLanguage.innerText = selectedLanguageLists.join(", ");
			document.getElementById("asw-website-lang").innerText = `Languages: ${selectedLanguageLists.join(", ")}`;
		}
	}

	function updateWidgetLanguagesList(event) {
		function translateText(translations) {
			Object.keys(translations).forEach((key) => {
				const elements = document.querySelectorAll(`[data-ap-translate="${key}"]`);
				elements.forEach((el) => {
					el.innerHTML = translations[key];
				});
			});
		}

		fetch(apAdminLocalizer.apiUrl + "/ap/v1/public/translate", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify({ translateTo: event.target.value }),
		})
		.then((res) => res.json())
		.then((data) => translateText(data.data));
	}
	
	function updateTranslationLanguageList(event) {
		const lang = event.target.value

		if (lang == "all") {
			translationLanguageLists = ["all"]
		} else {
			const found = translationLanguageLists.find(item => item === lang)
			if (!found) {
				translationLanguageLists.push(lang)
			} else {
				translationLanguageLists = translationLanguageLists.filter(item => item !== lang)
			}
		}
		if(translationLanguageLists.length > 1 && translationLanguageLists[0] === "all") {
			translationLanguageLists = translationLanguageLists.splice(1, translationLanguageLists.length);
		}

		if (translationLanguageLists.length == widgetLanguages.length) {
			translationLanguageLists = ["all"]
		}
      	prepareSelectedTranslationLanguage();
	}

	function removeSelectedTranslateLanguage(lang) {
		translationLanguageLists = translationLanguageLists.filter(item => item != lang)
		prepareSelectedTranslationLanguage();
	}

	function prepareSelectedTranslationLanguage() {
		const wrapper = document.getElementById("apSelectedTranslateLanguage");
		wrapper.innerHTML = "";
		translationLanguageLists.forEach(language => {
			const tagBody = document.createElement("span")
			tagBody.classList.add("ap-selected-translate-language");
			tagBody.innerHTML = `
				${language == 'all' ? 'All' : widgetLanguages.find(lang => lang.value == language).label} <span class="ap-cursor-pointer" onclick="removeSelectedTranslateLanguage('${language}')">&times;</span>
			`;
			wrapper.appendChild(tagBody)
		})
	}
	
	function changeRangeThumb(color) {
		const newThumb = `
		.ap-range-input::-webkit-slider-thumb {
			-webkit-appearance: none;
			appearance: none;
			width: 26px;
			height: 26px;
			background: url("data:image/svg+xml,%3Csvg width='29' height='40' viewBox='0 0 29 40' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Crect x='1.43933' y='1' width='25.6797' height='38' rx='9' fill='%23${color.slice(
			1
			)}'/%3E%3Crect x='1.43933' y='1' width='25.6797' height='38' rx='9' stroke='white' stroke-width='2'/%3E%3Cmask id='mask0_884_1082' style='mask-type:alpha' maskUnits='userSpaceOnUse' x='2' y='8' width='25' height='24'%3E%3Crect x='2.27917' y='8' width='24' height='24' fill='%23D9D9D9'/%3E%3C/mask%3E%3Cg mask='url(%23mask0_884_1082)'%3E%3Cpath d='M11.2792 28C10.7292 28 10.2583 27.8042 9.86667 27.4125C9.47501 27.0208 9.27917 26.55 9.27917 26C9.27917 25.45 9.47501 24.9792 9.86667 24.5875C10.2583 24.1958 10.7292 24 11.2792 24C11.8292 24 12.3 24.1958 12.6917 24.5875C13.0833 24.9792 13.2792 25.45 13.2792 26C13.2792 26.55 13.0833 27.0208 12.6917 27.4125C12.3 27.8042 11.8292 28 11.2792 28ZM17.2792 28C16.7292 28 16.2583 27.8042 15.8667 27.4125C15.475 27.0208 15.2792 26.55 15.2792 26C15.2792 25.45 15.475 24.9792 15.8667 24.5875C16.2583 24.1958 16.7292 24 17.2792 24C17.8292 24 18.3 24.1958 18.6917 24.5875C19.0833 24.9792 19.2792 25.45 19.2792 26C19.2792 26.55 19.0833 27.0208 18.6917 27.4125C18.3 27.8042 17.8292 28 17.2792 28ZM11.2792 22C10.7292 22 10.2583 21.8042 9.86667 21.4125C9.47501 21.0208 9.27917 20.55 9.27917 20C9.27917 19.45 9.47501 18.9792 9.86667 18.5875C10.2583 18.1958 10.7292 18 11.2792 18C11.8292 18 12.3 18.1958 12.6917 18.5875C13.0833 18.9792 13.2792 19.45 13.2792 20C13.2792 20.55 13.0833 21.0208 12.6917 21.4125C12.3 21.8042 11.8292 22 11.2792 22ZM17.2792 22C16.7292 22 16.2583 21.8042 15.8667 21.4125C15.475 21.0208 15.2792 20.55 15.2792 20C15.2792 19.45 15.475 18.9792 15.8667 18.5875C16.2583 18.1958 16.7292 18 17.2792 18C17.8292 18 18.3 18.1958 18.6917 18.5875C19.0833 18.9792 19.2792 19.45 19.2792 20C19.2792 20.55 19.0833 21.0208 18.6917 21.4125C18.3 21.8042 17.8292 22 17.2792 22ZM11.2792 16C10.7292 16 10.2583 15.8042 9.86667 15.4125C9.47501 15.0208 9.27917 14.55 9.27917 14C9.27917 13.45 9.47501 12.9792 9.86667 12.5875C10.2583 12.1958 10.7292 12 11.2792 12C11.8292 12 12.3 12.1958 12.6917 12.5875C13.0833 12.9792 13.2792 13.45 13.2792 14C13.2792 14.55 13.0833 15.0208 12.6917 15.4125C12.3 15.8042 11.8292 16 11.2792 16ZM17.2792 16C16.7292 16 16.2583 15.8042 15.8667 15.4125C15.475 15.0208 15.2792 14.55 15.2792 14C15.2792 13.45 15.475 12.9792 15.8667 12.5875C16.2583 12.1958 16.7292 12 17.2792 12C17.8292 12 18.3 12.1958 18.6917 12.5875C19.0833 12.9792 19.2792 13.45 19.2792 14C19.2792 14.55 19.0833 15.0208 18.6917 15.4125C18.3 15.8042 17.8292 16 17.2792 16Z' fill='white'/%3E%3C/g%3E%3C/svg%3E%0A") center center no-repeat;
			background-size: cover;
			cursor: pointer;
		}
	`;
		document.getElementById("apRangeStyle").innerHTML = newThumb;
	}

	window.saveSettings = saveSettings;
	window.resetSettings = resetSettings;
	window.toggleMenu = toggleMenu;
	window.toggleIconPosition = toggleIconPosition;
	window.toggleLayoutDisplay = toggleLayoutDisplay;
	window.toggleLanguageDisplay = toggleLanguageDisplay;
	window.changeColor = changeColor;
	window.updateLanguagesList = updateLanguagesList;
	window.updateWidgetLanguagesList = updateWidgetLanguagesList;
	window.updateTranslationLanguageList = updateTranslationLanguageList;
	window.changeIconSize = changeIconSize;
	window.changeMenuFontColor = changeMenuFontColor;
	window.changeMenuHeaderBgColor = changeMenuHeaderBgColor;
	window.changeMenuHeaderColor = changeMenuHeaderColor;
	window.openResetDialog = openResetDialog;
	window.closeResetDialog = closeResetDialog;
	window.removeSelectedTranslateLanguage = removeSelectedTranslateLanguage;

	$( window ).load(function() {
		const { 
			icon, position, icon_stroke_color, icon_fill_color,
			icon_size, enable_features, enable_language, language_list,
			menu_header_bg_color, menu_header_font_color, menu_content_color,
			default_language, translation_language_list, api_key
		} = apAllConfigsLocalizer;
		const previewIcon = document.getElementById("asw-icon");
		
		// populate api key
		$('input[name="api_key"]').val(api_key);
		// Update Icon
		$('input[name="position"]').each(function () {
			if (this.value === position) {
				this.checked = true;
				const wrapper = this.closest(".ap-icon-position");
				wrapper.style.background = "#1E1E1E";
				wrapper.style.color = "#FFF";
				wrapper
					.querySelector("svg")
					.querySelector("path")
					.setAttribute("fill", "#fff");
			} else {
				this.checked = false;
			}
		});
		$('input[name="icon_stroke_color"]').val(icon_stroke_color);
		$('input[name="icon_fill_color"]').val(icon_fill_color);

		$("#apMenuIconStroke").attr("stroke", icon_stroke_color);
		$("#apPreviewIconStroke").attr("stroke", icon_stroke_color);
		$("#apMenuIconFill").attr("fill", icon_fill_color);
		$("#apPreviewIconFill").attr("fill", icon_fill_color);

		const menuIcon = document.getElementById("apMenuIcon");
		const widget = document.getElementById("aswMenu");
		if (icon_size == "1x") {
			menuIcon && menuIcon.classList.remove("ap-x2")
			document.getElementById("size1x").checked = true;
			previewIcon.style.width = "60px";
			previewIcon.style.height = "60px";
		} else if (icon_size == "1.5x") {
			menuIcon && menuIcon.classList.add("ap-x15")
			document.getElementById("size15x").checked = true;
			previewIcon.style.width = "75px";
			previewIcon.style.height = "75px";
		} else if (icon_size == "2x") {
			menuIcon && menuIcon.classList.add("ap-x2")
			document.getElementById("size2x").checked = true;
			previewIcon.style.width = "90px";
			previewIcon.style.height = "90px";
		}

		const positionStyle = cssPositions[position];

		if (positionStyle) {
			previewIcon.style.left = '';
			previewIcon.style.right = '';
			previewIcon.style.top = '';
			previewIcon.style.bottom = '';
			for (const [property, value] of Object.entries(positionStyle)) {
				previewIcon.style[property] = value;
				widget.style[property] = value;
			}
			widget.style.zIndex = Number.MAX_SAFE_INTEGER;
			if (position == "middle-right" || position == "middle-left") {
				widget.style.transform = "translateY(-50%)";
			}
			
			if (window.matchMedia("(max-width: 960px)").matches) {
				if (position == "top-left" || position == "middle-left" || position == "bottom-left") {
					previewIcon.style.left = "20px";
					widget.style.left = "20px";
				}
			}
		}

		// Update Menu
		$('input[name="menu_header_bg_color"]').val(menu_header_bg_color);
		$('input[name="menu_header_font_color"]').val(menu_header_font_color);
		$('input[name="menu_content_color"]').val(menu_content_color);
		document.querySelector(".asw-menu-header").style.background = menu_header_bg_color
		document.querySelector(".asw-menu-header").style.color = menu_header_font_color
		document
		.querySelectorAll(
			`[data-ap-translate]:not([data-ap-translate="MENU TITLE"]):not([data-ap-translate="OFF"]):not([data-ap-translate="ON"]),#ap-selected-language,[data-lang],.ap-range-value`
		)
		.forEach((el) => {
			el.style.color = menu_content_color;
		});
		document.querySelectorAll(".asw-menu svg,.asw-widget svg").forEach(el => {
			el.querySelector("path").setAttribute("fill", menu_content_color);
		})
		document.querySelectorAll(".ap-border-bottom").forEach((el) => {
			el.style.borderBottom = `1px solid ${menu_header_bg_color}`;
		});
		document.querySelectorAll(".ap-setting-button").forEach((el) => {
			el.style.border = `2px solid ${menu_content_color}`;
		});
		document.querySelectorAll(".ap-setting").forEach((el) => {
			el.addEventListener("mouseover", () => {
				el.style.border = `3px solid ${menu_content_color}`;
			});
		});
		changeRangeThumb(menu_content_color);

		document.querySelectorAll(".ap-setting").forEach((el) => {
			el.addEventListener("mouseleave", () => {
				el.style.border = `3px solid transparent`;
			});
		});

		if (enable_language === "1" && JSON.parse(language_list).length > 0) {
			document.getElementById("asw-website-lang").innerText = `Languages: ${JSON.parse(language_list).join(", ")}`;
		} else {
			document.getElementById("asw-website-lang").style.display = "none";
		}

		// Update Language
		if (enable_language === '1') {
			document.getElementById('apBtnEnableLanguage').checked = true;
			document.querySelector(".ap-disable-language-overlay").style.display = "none";
		} else {
			document.querySelector(".ap-disable-language-overlay").style.display = "block";
		}

		translationLanguageLists = JSON.parse(translation_language_list);
		prepareSelectedTranslationLanguage();

		// Update Language List
		selectedLanguageLists = JSON.parse(language_list);
		const selectedLanguage = document.getElementById("apSelectedLanguage");

		if (selectedLanguageLists.length == 0) {
			selectedLanguage.innerText = "No language selected.";
		} else {
			selectedLanguage.innerText = selectedLanguageLists.join(", ");
		}

		const languageDropDown = document.getElementById("apLanguageSelectDropDown");
		languages.forEach(language => {
			const option = document.createElement("option");
			option.value = language.code;
			option.text = `${language.name}: ${language.code}`;
			languageDropDown.appendChild(option);
		})
		
		const widgetLanguageDropDown = document.getElementById("apWidgetLanguageSelectDropDown");
		const widgetShowcaseLanguageDropDown = document.getElementById("apWidgetShowcaseLanguage");
		widgetLanguages.forEach(language => {
			const option = document.createElement("option");
			option.value = language.value;
			option.text = language.label;
			widgetLanguageDropDown.appendChild(option);

			const option2 = document.createElement("option");
			option2.value = language.value;
			option2.text = language.label;
			widgetShowcaseLanguageDropDown.appendChild(option2);
		})
		
		widgetLanguageDropDown.value = default_language || "en";

		// display menu icon
		if (enable_features === '1') {
            document.getElementById('apBtnEnableFeature').checked = true;
			document.getElementById("ap-enable-status").innerText = "enabled";
			document.querySelector(".ap-disable-icon-overlay").style.display = "none";
			previewIcon.style.display = "block";
        } else {
			document.querySelector(".ap-disable-icon-overlay").style.display = "block";
		}

		const draggableHeader = document.getElementById("draggableHeader");
		const aswMenu = document.getElementById("aswMenu");

		draggableHeader.addEventListener("mousedown", (e) => {
			isDragging = true;
			offsetX = e.clientX - aswMenu.getBoundingClientRect().left;
			offsetY = e.clientY - aswMenu.getBoundingClientRect().top;
			aswMenu.style.cursor = "grabbing";
		});

		document.addEventListener("mousemove", (e) => {
			if (!isDragging) return;

			let x = e.clientX - offsetX;
			let y = e.clientY - offsetY;

			// Ensure the new position is within the viewport boundaries
			x = Math.max(0, Math.min(x, window.innerWidth - aswMenu.offsetWidth));
			y = Math.max(0, Math.min(y, window.innerHeight - aswMenu.offsetHeight));

			aswMenu.style.top = `${y}px`;
			aswMenu.style.left = `${x}px`;
			aswMenu.style.transform = "translateY(0)";
		});

		document.addEventListener("mouseup", () => {
			isDragging = false;
		});
	})

})( jQuery );
