<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://qodemedia.com
 * @since      1.0.0
 *
 * @package    Access_Pro
 * @subpackage Access_Pro/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Access_Pro
 * @subpackage Access_Pro/includes
 * @author     qodemedia <avi@qodemedia.com>
 */
class Access_Pro_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
