<?php

/**
 * Fired during plugin activation
 *
 * @link       https://qodemedia.com
 * @since      1.0.0
 *
 * @package    Access_Pro
 * @subpackage Access_Pro/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Access_Pro
 * @subpackage Access_Pro/includes
 * @author     qodemedia <avi@qodemedia.com>
 */
class Access_Pro_Activator {

	public static function activate() {
		self::delete_config_table();
		self::create_config_table();
	}

	public static function delete_config_table()
	{
		global $wpdb;
		$prefix = $wpdb->prefix . "access_pro_";

		$table_name = $prefix . "configs";
		$wpdb->query("DROP TABLE IF EXISTS $table_name");
	}

	public static function create_config_table() {
		ini_set('max_execution_time', 0);

		error_reporting(E_ALL);
		ini_set('display_errors', '1');


		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

		global $wpdb;
		$charset_collate = 'UTF8MB4';
		$prefix 	 	 = $wpdb->prefix . "access_pro_";

		$sql = "CREATE TABLE IF NOT EXISTS `{$prefix}configs` (
			  `id` int unsigned NOT NULL AUTO_INCREMENT,
			  `key` varchar(50) DEFAULT NULL,
			  `value` varchar(200) DEFAULT NULL,
			  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
			  PRIMARY KEY (`id`)
			)  DEFAULT CHARSET={$charset_collate};";
		dbDelta($sql);

		// Add Configs
		self::add_configs();
	}


	private static function add_configs() {
		global $wpdb;
		$prefix = $wpdb->prefix . "access_pro_";


		$asl_configs = array(
			array('icon', 'icon1'),
			array('position', 'bottom-left'),
			array('icon_stroke_color', '#419d4a'),
			array('icon_fill_color', '#419d4a'),
			array('icon_size', '1x'),
			array('menu_content_color', '#000000'),
			array('menu_header_bg_color', '#000000'),
			array('menu_header_font_color', '#ffffff'),
			array('enable_features', '1'),
			array('enable_language', '0'),
			array('language_list', '[]'),
			array('translation_language_list', '["all"]'),
			array('default_language', 'en'),
			array('api_key', ''),
		);

		foreach ($asl_configs as $_config) {
			$key = sanitize_text_field($_config[0]);
			$val = sanitize_text_field($_config[1]);

			//validate if not exist, else enter it
			$c = $wpdb->get_results("SELECT count(*) AS 'c' FROM `{$prefix}configs` WHERE `key` = '{$key}'");
			if ($c[0]->c == 0) {
				$sql =  "INSERT INTO `{$prefix}configs`(`key`,`value`) VALUES ('{$key}','{$val}');";
				dbDelta($sql);
			}
		}
	}

}
